package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Instrument(
    val label: String,
    val category: String,
    val symbol: String,
    val provider: String
)

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

data class Pivot(val index: Int, val price: Double)

data class Zone(
    val low: Double,
    val high: Double,
    val type: String,
    val description: String,
    val index: Int
)

data class Setup(
    val direction: String,
    val zone: Zone,
    val sweepExtreme: Double,
    val bosIndex: Int
)

data class SignalResult(
    val signal: String,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val currentPrice: Double,
    val bias: String,
    val zoneName: String,
    val details: String
)

class MainActivity : Activity() {

    private val background = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(21, 29, 49)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 196, 220)
    private val green = Color.rgb(53, 211, 154)
    private val red = Color.rgb(255, 101, 119)
    private val gold = Color.rgb(255, 200, 87)

    private lateinit var categorySpinner: Spinner
    private lateinit var marketSpinner: Spinner
    private lateinit var timeframeSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var scanButton: Button
    private lateinit var resultBox: LinearLayout

    private var scanning = false

    private val categories = listOf(
        "ALL", "CRYPTO", "INDIA", "FOREX", "METALS"
    )

    private val instruments = listOf(
        Instrument("BTC / USDT", "CRYPTO", "BTCUSDT", "BINANCE"),
        Instrument("ETH / USDT", "CRYPTO", "ETHUSDT", "BINANCE"),
        Instrument("BNB / USDT", "CRYPTO", "BNBUSDT", "BINANCE"),
        Instrument("SOL / USDT", "CRYPTO", "SOLUSDT", "BINANCE"),
        Instrument("XRP / USDT", "CRYPTO", "XRPUSDT", "BINANCE"),
        Instrument("DOGE / USDT", "CRYPTO", "DOGEUSDT", "BINANCE"),
        Instrument("1000PEPE / USDT", "CRYPTO", "1000PEPEUSDT", "BINANCE"),
        Instrument("PAXG / USDT", "CRYPTO", "PAXGUSDT", "BINANCE"),
        Instrument("ZEC / USDT", "CRYPTO", "ZECUSDT", "BINANCE"),
        Instrument("TRX / USDT", "CRYPTO", "TRXUSDT", "BINANCE"),

        Instrument("NIFTY 50", "INDIA", "NIFTY", "NOT_CONNECTED"),
        Instrument("BANK NIFTY", "INDIA", "BANKNIFTY", "NOT_CONNECTED"),
        Instrument("SENSEX", "INDIA", "SENSEX", "NOT_CONNECTED"),
        Instrument("FINNIFTY", "INDIA", "FINNIFTY", "NOT_CONNECTED"),
        Instrument("MIDCAP NIFTY", "INDIA", "MIDCPNIFTY", "NOT_CONNECTED"),

        Instrument("EUR / USD", "FOREX", "EURUSD", "NOT_CONNECTED"),
        Instrument("GBP / USD", "FOREX", "GBPUSD", "NOT_CONNECTED"),
        Instrument("USD / JPY", "FOREX", "USDJPY", "NOT_CONNECTED"),

        Instrument("GOLD / USD", "METALS", "XAUUSD", "NOT_CONNECTED"),
        Instrument("SILVER / USD", "METALS", "XAGUSD", "NOT_CONNECTED")
    )

    private var visibleMarkets: List<Instrument> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(background)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(18), dp(16), dp(24))
        root.setBackgroundColor(background)

        scroll.addView(
            root,
            ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val title = TextView(this)
        title.text = "SMC ICT SIGNAL PRO"
        title.textSize = 25f
        title.setTextColor(white)
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "MARKET SCANNER  •  SMC / ICT RULE-BASED MODEL"
        subtitle.textSize = 11f
        subtitle.setTextColor(muted)
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, dp(7), 0, dp(18))
        root.addView(subtitle)

        addLabel(root, "MARKET CATEGORY")
        categorySpinner = createSpinner(categories)
        root.addView(categorySpinner, matchWrap())

        addLabel(root, "SELECT MARKET")
        marketSpinner = createSpinner(emptyList())
        root.addView(marketSpinner, matchWrap())

        addLabel(root, "TIMEFRAME")
        timeframeSpinner = createSpinner(
            listOf("1m", "5m", "15m", "1h", "4h", "1d")
        )
        root.addView(timeframeSpinner, matchWrap())

        scanButton = Button(this)
        scanButton.text = "SCAN MARKET"
        scanButton.textSize = 16f
        scanButton.setTextColor(Color.BLACK)
        scanButton.setBackgroundColor(gold)
        scanButton.typeface = Typeface.DEFAULT_BOLD

        val buttonParams = matchWrap()
        buttonParams.topMargin = dp(18)
        buttonParams.bottomMargin = dp(15)
        root.addView(scanButton, buttonParams)

        statusText = TextView(this)
        statusText.text = "Ready • Select a crypto market"
        statusText.textSize = 13f
        statusText.setTextColor(muted)
        statusText.gravity = Gravity.CENTER
        statusText.setPadding(dp(8), dp(10), dp(8), dp(10))
        root.addView(statusText, matchWrap())

        resultBox = LinearLayout(this)
        resultBox.orientation = LinearLayout.VERTICAL
        resultBox.setPadding(dp(14), dp(14), dp(14), dp(14))
        resultBox.setBackgroundColor(panel)

        val resultParams = matchWrap()
        resultParams.topMargin = dp(10)
        root.addView(resultBox, resultParams)

        addResultLine("Signal: WAIT", muted, 20f)
        addResultLine("Entry Price: —", white, 15f)
        addResultLine("Stop Loss: —", white, 15f)
        addResultLine("Target 1: —", white, 15f)
        addResultLine("Target 2: —", white, 15f)

        val note = TextView(this)
        note.text =
            "Note: Live Binance data is used for supported crypto pairs. " +
            "India, Forex and Metals feeds are not connected yet. " +
            "Signals are rule-based analysis and are not guaranteed."
        note.textSize = 11f
        note.setTextColor(muted)
        note.setPadding(dp(4), dp(16), dp(4), 0)
        root.addView(note)

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateMarkets()
                }
            }

        scanButton.setOnClickListener {
            scanSelectedMarket()
        }

        updateMarkets()
        setContentView(scroll)
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        val label = TextView(this)
        label.text = text
        label.textSize = 12f
        label.setTextColor(white)
        label.typeface = Typeface.DEFAULT_BOLD
        label.setPadding(dp(2), dp(12), 0, dp(6))
        parent.addView(label)
    }

    private fun createSpinner(items: List<String>): Spinner {
        val spinner = Spinner(this)
        spinner.adapter = WhiteSpinnerAdapter(items)
        spinner.setBackgroundColor(panel)
        return spinner
    }

    private inner class WhiteSpinnerAdapter(
        private val items: List<String>
    ) : android.widget.BaseAdapter() {

        override fun getCount(): Int = items.size

        override fun getItem(position: Int): String = items[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?
        ): View {
            return makeSpinnerText(items[position], false)
        }

        override fun getDropDownView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?
        ): View {
            return makeSpinnerText(items[position], true)
        }

        private fun makeSpinnerText(text: String, dropdown: Boolean): TextView {
            val view = TextView(this@MainActivity)
            view.text = text
            view.setTextColor(white)
            view.textSize = 15f
            view.gravity = Gravity.CENTER_VERTICAL
            view.setPadding(dp(12), dp(12), dp(12), dp(12))
            view.setBackgroundColor(panel)
            if (dropdown) {
                view.minHeight = dp(46)
            }
            return view
        }
    }

    private fun updateMarkets() {
        val selectedCategory =
            categorySpinner.selectedItem?.toString() ?: "ALL"

        visibleMarkets = if (selectedCategory == "ALL") {
            instruments
        } else {
            instruments.filter { it.category == selectedCategory }
        }

        marketSpinner.adapter = WhiteSpinnerAdapter(
            visibleMarkets.map { it.label }
        )

        if (visibleMarkets.isNotEmpty()) {
            marketSpinner.setSelection(0)
        }
    }

    private fun scanSelectedMarket() {
        if (scanning) return

        val market = visibleMarkets.getOrNull(
            marketSpinner.selectedItemPosition
        )

        if (market == null) {
            statusText.text = "Please select a market"
            return
        }

        if (market.provider != "BINANCE") {
            showResult(
                waitResult(
                    "WAIT",
                    "Live data feed is not connected for ${market.label}."
                )
            )
            statusText.text =
                "${market.label} • Data provider not connected"
            return
        }

        val timeframe =
            timeframeSpinner.selectedItem?.toString() ?: "15m"

        scanning = true
        scanButton.isEnabled = false
        scanButton.text = "SCANNING..."
        statusText.text = "Fetching live market data..."

        thread {
            try {
                val candles = fetchCandles(market.symbol, timeframe)

                if (candles.size < 60) {
                    throw Exception("Not enough candle data")
                }

                val higherTimeframe = getHigherTimeframe(timeframe)
                val higherCandles =
                    fetchCandles(market.symbol, higherTimeframe)

                val result = analyzeMarket(
                    candles,
                    higherCandles,
                    market.label,
                    timeframe
                )

                runOnUiThread {
                    showResult(result)
                    statusText.text =
                        "${market.label} • $timeframe • Scan complete"
                    finishScanning()
                }

            } catch (e: Exception) {
                runOnUiThread {
                    showResult(
                        waitResult(
                            "WAIT",
                            e.message ?: "Unable to fetch market data."
                        )
                    )
                    statusText.text = "Scan failed • Check internet connection"
                    finishScanning()
                }
            }
        }
    }

    private fun finishScanning() {
        scanning = false
        scanButton.isEnabled = true
        scanButton.text = "SCAN MARKET"
    }

    private fun fetchCandles(
        symbol: String,
        interval: String
    ): List<Candle> {
        val url = URL(
            "https://api.binance.com/api/v3/klines" +
                "?symbol=$symbol&interval=$interval&limit=250"
        )

        val connection =
            url.openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.setRequestProperty(
            "User-Agent",
            "SMC-ICT-Signal-Pro"
        )

        try {
            val responseCode = connection.responseCode

            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw Exception("Binance API error: HTTP $responseCode")
            }

            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val json = JSONArray(response)
            val candles = mutableListOf<Candle>()

            for (i in 0 until json.length()) {
                val row = json.getJSONArray(i)

                candles.add(
                    Candle(
                        open = row.getString(1).toDouble(),
                        high = row.getString(2).toDouble(),
                        low = row.getString(3).toDouble(),
                        close = row.getString(4).toDouble()
                    )
                )
            }

            // Last candle may still be forming. Exclude it.
            if (candles.isNotEmpty()) {
                candles.removeAt(candles.lastIndex)
            }

            return candles

        } finally {
            connection.disconnect()
        }
    }

    private fun getHigherTimeframe(timeframe: String): String {
        return when (timeframe) {
            "1m" -> "5m"
            "5m" -> "15m"
            "15m" -> "1h"
            "1h" -> "4h"
            "4h" -> "1d"
            "1d" -> "1w"
            else -> "1h"
        }
    }

    private fun analyzeMarket(
        candles: List<Candle>,
        higherCandles: List<Candle>,
        market: String,
        timeframe: String
    ): SignalResult {

        if (candles.size < 60 || higherCandles.size < 30) {
            return waitResult(
                "WAIT",
                "Insufficient candle data for reliable analysis."
            )
        }

        val currentPrice = candles.last().close
        val atr = calculateAtr(candles, 14)

        if (atr <= 0.0) {
            return waitResult("WAIT", "ATR calculation unavailable.")
        }

        val bias = calculateStructureBias(higherCandles)

        if (bias == "NEUTRAL") {
            return waitResult(
                "WAIT",
                "Higher timeframe structure is neutral. No trade."
            ).copy(bias = bias, currentPrice = currentPrice)
        }

        val setup = findSequentialSetup(candles, atr)

        if (setup == null) {
            return waitResult(
                "WAIT",
                "No confirmed liquidity sweep + BOS + zone retest setup."
            ).copy(bias = bias, currentPrice = currentPrice)
        }

        if (setup.direction == "BUY" && bias != "BULLISH") {
            return waitResult(
                "WAIT",
                "Bullish setup rejected because higher timeframe bias is not bullish."
            ).copy(bias = bias, currentPrice = currentPrice)
        }

        if (setup.direction == "SELL" && bias != "BEARISH") {
            return waitResult(
                "WAIT",
                "Bearish setup rejected because higher timeframe bias is not bearish."
            ).copy(bias = bias, currentPrice = currentPrice)
        }

        val zone = setup.zone
        val entry = (zone.low + zone.high) / 2.0

        val stopLoss: Double
        val risk: Double
        val target1: Double
        val target2: Double

        if (setup.direction == "BUY") {
            stopLoss = min(
                zone.low,
                setup.sweepExtreme
            ) - atr * 0.20

            risk = entry - stopLoss

            if (currentPrice <= entry) {
                return waitResult(
                    "WAIT",
                    "Price has not confirmed a bullish move away from the entry zone."
                ).copy(
                    bias = bias,
                    currentPrice = currentPrice,
                    zoneName = zone.description
                )
            }

            target1 = entry + risk * 2.0
            target2 = entry + risk * 3.0

            if (currentPrice <= stopLoss || currentPrice >= target1) {
                return waitResult(
                    "WAIT",
                    "Entry is no longer valid: stop or first target already crossed."
                ).copy(
                    bias = bias,
                    currentPrice = currentPrice,
                    zoneName = zone.description
                )
            }

        } else {
            stopLoss = max(
                zone.high,
                setup.sweepExtreme
            ) + atr * 0.20

            risk = stopLoss - entry

            if (currentPrice >= entry) {
                return waitResult(
                    "WAIT",
                    "Price has not confirmed a bearish move away from the entry zone."
                ).copy(
                    bias = bias,
                    currentPrice = currentPrice,
                    zoneName = zone.description
                )
            }

            target1 = entry - risk * 2.0
            target2 = entry - risk * 3.0

            if (currentPrice >= stopLoss || currentPrice <= target1) {
                return waitResult(
                    "WAIT",
                    "Entry is no longer valid: stop or first target already crossed."
                ).copy(
                    bias = bias,
                    currentPrice = currentPrice,
                    zoneName = zone.description
                )
            }
        }

        if (risk <= 0.0 || risk > atr * 4.0) {
            return waitResult(
                "WAIT",
                "Risk is too large or invalid for this setup."
            ).copy(
                bias = bias,
                currentPrice = currentPrice,
                zoneName = zone.description
            )
        }

        if (abs(currentPrice - entry) > atr * 1.2) {
            return waitResult(
                "WAIT",
                "Price has moved too far from the planned entry."
            ).copy(
                bias = bias,
                currentPrice = currentPrice,
                zoneName = zone.description
            )
        }

        return SignalResult(
            signal = setup.direction,
            entry = entry,
            stopLoss = stopLoss,
            target1 = target1,
            target2 = target2,
            currentPrice = currentPrice,
            bias = bias,
            zoneName = zone.description,
            details =
                "Confirmed liquidity sweep, BOS, displacement, " +
                    "zone retest and higher timeframe alignment. " +
                    "Market: $market • Timeframe: $timeframe"
        )
    }

    private fun findSequentialSetup(
        candles: List<Candle>,
        atr: Double
    ): Setup? {

        val n = candles.size
        if (n < 60) return null

        val highs = findPivotHighs(candles)
        val lows = findPivotLows(candles)

        // Search recent completed candles, not the forming candle.
        for (sweepIndex in (n - 6) downTo max(10, n - 45)) {

            val confirmedHighs = highs.filter {
                it.index <= sweepIndex - 2 &&
                    sweepIndex - it.index <= 40
            }

            val confirmedLows = lows.filter {
                it.index <= sweepIndex - 2 &&
                    sweepIndex - it.index <= 40
            }

            val lastHigh = confirmedHighs.maxByOrNull { it.index }
            val lastLow = confirmedLows.maxByOrNull { it.index }

            val candle = candles[sweepIndex]

            val bullishSweep =
                lastLow != null &&
                    candle.low < lastLow.price &&
                    candle.close > lastLow.price

            val bearishSweep =
                lastHigh != null &&
                    candle.high > lastHigh.price &&
                    candle.close < lastHigh.price

            if (!bullishSweep && !bearishSweep) continue

            val direction = if (bullishSweep) "BUY" else "SELL"

            val bosIndex = if (direction == "BUY") {
                findBullishBos(
                    candles,
                    sweepIndex,
                    lastHigh?.price,
                    atr
                )
            } else {
                findBearishBos(
                    candles,
                    sweepIndex,
                    lastLow?.price,
                    atr
                )
            } ?: continue

            val zone = findFairValueGap(
                candles,
                sweepIndex,
                bosIndex,
                direction,
                atr
            ) ?: findOrderBlock(
                candles,
                sweepIndex,
                bosIndex,
                direction,
                atr
            ) ?: continue

            if (zone.index > bosIndex) continue

            val retestConfirmed = if (direction == "BUY") {
                hasRecentBullishRetest(
                    candles,
                    zone,
                    bosIndex
                )
            } else {
                hasRecentBearishRetest(
                    candles,
                    zone,
                    bosIndex
                )
            }

            if (!retestConfirmed) continue

            val sweepExtreme = if (direction == "BUY") {
                candles.subList(sweepIndex, bosIndex + 1)
                    .minOf { it.low }
            } else {
                candles.subList(sweepIndex, bosIndex + 1)
                    .maxOf { it.high }
            }

            return Setup(
                direction = direction,
                zone = zone,
                sweepExtreme = sweepExtreme,
                bosIndex = bosIndex
            )
        }

        return null
    }

    private fun findBullishBos(
        candles: List<Candle>,
        sweepIndex: Int,
        level: Double?,
        atr: Double
    ): Int? {
        if (level == null) return null

        val start = sweepIndex + 1
        val end = min(candles.lastIndex, sweepIndex + 8)

        for (i in start..end) {
            val candle = candles[i]
            val body = candle.close - candle.open
            val avgBody = averageBody(
                candles,
                max(0, i - 10),
                i
            )

            val requiredBody = max(
                atr * 0.35,
                avgBody * 1.15
            )

            if (
                candle.close > level &&
                candle.close > candle.open &&
                body >= requiredBody
            ) {
                return i
            }
        }

        return null
    }

    private fun findBearishBos(
        candles: List<Candle>,
        sweepIndex: Int,
        level: Double?,
        atr: Double
    ): Int? {
        if (level == null) return null

        val start = sweepIndex + 1
        val end = min(candles.lastIndex, sweepIndex + 8)

        for (i in start..end) {
            val candle = candles[i]
            val body = candle.open - candle.close
            val avgBody = averageBody(
                candles,
                max(0, i - 10),
                i
            )

            val requiredBody = max(
                atr * 0.35,
                avgBody * 1.15
            )

            if (
                candle.close < level &&
                candle.close < candle.open &&
                body >= requiredBody
            ) {
                return i
            }
        }

        return null
    }

    private fun findFairValueGap(
        candles: List<Candle>,
        sweepIndex: Int,
        bosIndex: Int,
        direction: String,
        atr: Double
    ): Zone? {

        val firstIndex = max(sweepIndex + 2, bosIndex - 5)

        for (i in bosIndex downTo firstIndex) {
            if (i < 2) continue

            val older = candles[i - 2]
            val middle = candles[i - 1]
            val newer = candles[i]

            val avgBody = averageBody(
                candles,
                max(0, i - 10),
                i
            )

            val requiredDisplacement = max(
                atr * 0.25,
                avgBody * 1.15
            )

            if (direction == "BUY") {
                val gapLow = older.high
                val gapHigh = newer.low
                val middleBody = middle.close - middle.open
                val gapSize = gapHigh - gapLow

                if (
                    gapSize >= atr * 0.05 &&
                    gapSize <= atr * 1.5 &&
                    middle.close > middle.open &&
                    middleBody >= requiredDisplacement &&
                    gapHigh > gapLow
                ) {
                    return Zone(
                        low = gapLow,
                        high = gapHigh,
                        type = "FVG",
                        description = "Bullish Fair Value Gap",
                        index = i
                    )
                }

            } else {
                val gapLow = newer.high
                val gapHigh = older.low
                val middleBody = middle.open - middle.close
                val gapSize = gapHigh - gapLow

                if (
                    gapSize >= atr * 0.05 &&
                    gapSize <= atr * 1.5 &&
                    middle.close < middle.open &&
                    middleBody >= requiredDisplacement &&
                    gapHigh > gapLow
                ) {
                    return Zone(
                        low = gapLow,
                        high = gapHigh,
                        type = "FVG",
                        description = "Bearish Fair Value Gap",
                        index = i
                    )
                }
            }
        }

        return null
    }

    private fun findOrderBlock(
        candles: List<Candle>,
        sweepIndex: Int,
        bosIndex: Int,
        direction: String,
        atr: Double
    ): Zone? {

        val start = bosIndex - 1
        val end = max(sweepIndex + 1, bosIndex - 8)

        for (i in start downTo end) {
            val candle = candles[i]
            val range = candle.high - candle.low
            val body = abs(candle.close - candle.open)

            if (range <= 0.0 || body <= 0.0) continue
            if (range > atr * 2.0) continue

            if (direction == "BUY") {
                if (candle.close < candle.open) {
                    val low = candle.low
                    val high = candle.open
                    val size = high - low

                    if (
                        size > 0.0 &&
                        size <= atr * 1.5 &&
                        high > low
                    ) {
                        return Zone(
                            low = low,
                            high = high,
                            type = "OB",
                            description = "Bullish Order Block",
                            index = i
                        )
                    }
                }
            } else {
                if (candle.close > candle.open) {
                    val low = candle.open
                    val high = candle.high
                    val size = high - low

                    if (
                        size > 0.0 &&
                        size <= atr * 1.5 &&
                        high > low
                    ) {
                        return Zone(
                            low = low,
                            high = high,
                            type = "OB",
                            description = "Bearish Order Block",
                            index = i
                        )
                    }
                }
            }
        }

        return null
    }

    private fun hasRecentBullishRetest(
        candles: List<Candle>,
        zone: Zone,
        bosIndex: Int
    ): Boolean {

        val lastIndex = candles.lastIndex
        if (lastIndex <= bosIndex + 1) return false

        // A close below the zone invalidates this bullish setup.
        for (i in zone.index + 1..lastIndex) {
            if (candles[i].close < zone.low) return false
        }

        // The latest completed candle must be the rejection candle.
        val rejection = candles[lastIndex]

        if (
            rejection.close <= rejection.open ||
            rejection.close <= zone.high
        ) {
            return false
        }

        val touchStart = max(bosIndex + 1, lastIndex - 3)

        for (touchIndex in touchStart until lastIndex) {
            val touch = candles[touchIndex]

            val touched =
                touch.low <= zone.high &&
                    touch.high >= zone.low

            if (!touched) continue

            if (
                rejection.low <= rejection.high &&
                rejection.close > zone.high &&
                rejection.close > rejection.open
            ) {
                return true
            }
        }

        return false
    }

    private fun hasRecentBearishRetest(
        candles: List<Candle>,
        zone: Zone,
        bosIndex: Int
    ): Boolean {

        val lastIndex = candles.lastIndex
        if (lastIndex <= bosIndex + 1) return false

        // A close above the zone invalidates this bearish setup.
        for (i in zone.index + 1..lastIndex) {
            if (candles[i].close > zone.high) return false
        }

        val rejection = candles[lastIndex]

        if (
            rejection.close >= rejection.open ||
            rejection.close >= zone.low
        ) {
            return false
        }

        val touchStart = max(bosIndex + 1, lastIndex - 3)

        for (touchIndex in touchStart until lastIndex) {
            val touch = candles[touchIndex]

            val touched =
                touch.high >= zone.low &&
                    touch.low <= zone.high

            if (!touched) continue

            if (
                rejection.close < zone.low &&
                rejection.close < rejection.open
            ) {
                return true
            }
        }

        return false
    }

    private fun findPivotHighs(
        candles: List<Candle>
    ): List<Pivot> {
        val result = mutableListOf<Pivot>()

        for (i in 2 until candles.size - 2) {
            val price = candles[i].high

            if (
                price > candles[i - 1].high &&
                price > candles[i - 2].high &&
                price > candles[i + 1].high &&
                price > candles[i + 2].high
            ) {
                result.add(Pivot(i, price))
            }
        }

        return result
    }

    private fun findPivotLows(
        candles: List<Candle>
    ): List<Pivot> {
        val result = mutableListOf<Pivot>()

        for (i in 2 until candles.size - 2) {
            val price = candles[i].low

            if (
                price < candles[i - 1].low &&
                price < candles[i - 2].low &&
                price < candles[i + 1].low &&
                price < candles[i + 2].low
            ) {
                result.add(Pivot(i, price))
            }
        }

        return result
    }

    private fun calculateStructureBias(
        candles: List<Candle>
    ): String {

        val highs = findPivotHighs(candles)
        val lows = findPivotLows(candles)

        if (highs.size < 2 || lows.size < 2) {
            return "NEUTRAL"
        }

        val lastTwoHighs = highs.takeLast(2)
        val lastTwoLows = lows.takeLast(2)

        val higherHigh =
            lastTwoHighs[1].price > lastTwoHighs[0].price

        val higherLow =
            lastTwoLows[1].price > lastTwoLows[0].price

        val lowerHigh =
            lastTwoHighs[1].price < lastTwoHighs[0].price

        val lowerLow =
            lastTwoLows[1].price < lastTwoLows[0].price

        return when {
            higherHigh && higherLow -> "BULLISH"
            lowerHigh && lowerLow -> "BEARISH"
            else -> "NEUTRAL"
        }
    }

    private fun calculateAtr(
        candles: List<Candle>,
        period: Int
    ): Double {
        if (candles.size <= period) return 0.0

        val start = candles.size - period
        var total = 0.0
        var count = 0

        for (i in start until candles.size) {
            val previousClose = candles[i - 1].close

            val trueRange = max(
                candles[i].high - candles[i].low,
                max(
                    abs(candles[i].high - previousClose),
                    abs(candles[i].low - previousClose)
                )
            )

            total += trueRange
            count++
        }

        return if (count == 0) 0.0 else total / count
    }

    private fun averageBody(
        candles: List<Candle>,
        start: Int,
        end: Int
    ): Double {
        if (end <= start) return 0.0

        var total = 0.0
        var count = 0

        for (i in start until end) {
            total += abs(candles[i].close - candles[i].open)
            count++
        }

        return if (count == 0) 0.0 else total / count
    }

    private fun waitResult(
        signal: String,
        details: String
    ): SignalResult {
        return SignalResult(
            signal = signal,
            entry = 0.0,
            stopLoss = 0.0,
            target1 = 0.0,
            target2 = 0.0,
            currentPrice = 0.0,
            bias = "NEUTRAL",
            zoneName = "Not confirmed",
            details = details
        )
    }

    private fun showResult(result: SignalResult) {
        resultBox.removeAllViews()

        val signalColor = when (result.signal) {
            "BUY" -> green
            "SELL" -> red
            else -> gold
        }

        addResultLine(
            "SIGNAL: ${result.signal}",
            signalColor,
            23f
        )

        addResultLine(
            "Current Price: ${formatPrice(result.currentPrice)}",
            white,
            15f
        )

        addResultLine(
            "Higher Timeframe Bias: ${result.bias}",
            white,
            14f
        )

        addResultLine(
            "Entry Price: ${formatPrice(result.entry)}",
            white,
            16f
        )

        addResultLine(
            "Stop Loss: ${formatPrice(result.stopLoss)}",
            red,
            16f
        )

        addResultLine(
            "Target 1 (1:2): ${formatPrice(result.target1)}",
            green,
            16f
        )

        addResultLine(
            "Target 2 (1:3): ${formatPrice(result.target2)}",
            green,
            16f
        )

        addResultLine(
            "SMC Zone: ${result.zoneName}",
            gold,
            13f
        )

        val divider = View(this)
        divider.setBackgroundColor(Color.rgb(55, 68, 91))
        val dividerParams = matchWrap()
        dividerParams.height = dp(1)
        dividerParams.topMargin = dp(10)
        dividerParams.bottomMargin = dp(10)
        resultBox.addView(divider, dividerParams)

        val details = TextView(this)
        details.text = result.details
        details.textSize = 12f
        details.setTextColor(muted)
        details.setPadding(0, dp(4), 0, dp(4))
        resultBox.addView(details, matchWrap())
    }

    private fun addResultLine(
        text: String,
        color: Int,
        size: Float
    ) {
        val view = TextView(this)
        view.text = text
        view.textSize = size
        view.setTextColor(color)
        view.typeface = Typeface.DEFAULT_BOLD
        view.setPadding(0, dp(7), 0, dp(7))
        resultBox.addView(view, matchWrap())
    }

    private fun formatPrice(value: Double): String {
        if (!value.isFinite() || value <= 0.0) return "—"

        return String.format(
            Locale.US,
            "%.8f",
            value
        ).trimEnd('0').trimEnd('.')
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun matchWrap(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}