package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Instrument(
    val label: String,
    val category: String,
    val symbol: String,
    val provider: String
)

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

data class SignalResult(
    val signal: String,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val details: String
)

data class Zone(
    val low: Double,
    val high: Double,
    val type: String
)

data class Setup(
    val bullish: Boolean,
    val sweepExtreme: Double,
    val zone: Zone,
    val structure: String
)

class MainActivity : Activity() {

    private val bg = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(21, 29, 49)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 196, 220)
    private val green = Color.rgb(53, 211, 154)
    private val red = Color.rgb(255, 101, 119)
    private val gold = Color.rgb(255, 200, 87)

    private lateinit var categorySpinner: Spinner
    private lateinit var marketSpinner: Spinner
    private lateinit var timeframeSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button

    private val categories = listOf(
        "ALL",
        "INDIA",
        "CRYPTO",
        "FOREX",
        "METALS"
    )

    private val timeframes = listOf(
        "1m", "5m", "15m", "1h", "4h", "1d"
    )

    private val instruments = listOf(

        Instrument("BTC / USDT", "CRYPTO", "BTCUSDT", "Binance"),
        Instrument("ETH / USDT", "CRYPTO", "ETHUSDT", "Binance"),
        Instrument("BNB / USDT", "CRYPTO", "BNBUSDT", "Binance"),
        Instrument("SOL / USDT", "CRYPTO", "SOLUSDT", "Binance"),
        Instrument("XRP / USDT", "CRYPTO", "XRPUSDT", "Binance"),
        Instrument("DOGE / USDT", "CRYPTO", "DOGEUSDT", "Binance"),
        Instrument("1000PEPE / USDT", "CRYPTO", "1000PEPEUSDT", "Binance"),
        Instrument("PAXG / USDT", "CRYPTO", "PAXGUSDT", "Binance"),
        Instrument("ZEC / USDT", "CRYPTO", "ZECUSDT", "Binance"),
        Instrument("TRX / USDT", "CRYPTO", "TRXUSDT", "Binance"),

        Instrument("NIFTY", "INDIA", "NIFTY", "Not connected"),
        Instrument("BANKNIFTY", "INDIA", "BANKNIFTY", "Not connected"),
        Instrument("SENSEX", "INDIA", "SENSEX", "Not connected"),
        Instrument("FINNIFTY", "INDIA", "FINNIFTY", "Not connected"),
        Instrument("MIDCPNIFTY", "INDIA", "MIDCPNIFTY", "Not connected"),

        Instrument("EUR / USD", "FOREX", "EURUSD", "Not connected"),
        Instrument("GBP / USD", "FOREX", "GBPUSD", "Not connected"),
        Instrument("USD / JPY", "FOREX", "USDJPY", "Not connected"),

        Instrument("GOLD / USD", "METALS", "XAUUSD", "Not connected"),
        Instrument("SILVER / USD", "METALS", "XAGUSD", "Not connected")
    )

    private var visibleMarkets = instruments.filter {
        it.category == "CRYPTO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "SMC ICT SIGNAL PRO"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        root.addView(title)
        addSpace(root, 8)

        val subtitle = TextView(this).apply {
            text = "SMART MONEY CONCEPTS • ICT ANALYSIS"
            textSize = 12f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }

        root.addView(subtitle)
        addSpace(root, 20)

        addLabel(root, "MARKET CATEGORY")

        categorySpinner = Spinner(this)
        root.addView(categorySpinner)
        categorySpinner.adapter = spinnerAdapter(categories)

        addSpace(root, 12)
        addLabel(root, "SELECT MARKET")

        marketSpinner = Spinner(this)
        root.addView(marketSpinner)

        addSpace(root, 12)
        addLabel(root, "TIMEFRAME")

        timeframeSpinner = Spinner(this)
        root.addView(timeframeSpinner)
        timeframeSpinner.adapter = spinnerAdapter(timeframes)
        timeframeSpinner.setSelection(2)

        addSpace(root, 18)

        scanButton = Button(this).apply {
            text = "SCAN MARKET"
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
        }

        root.addView(scanButton)
        addSpace(root, 15)

        statusText = TextView(this).apply {
            text = "Ready • Select a market"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }

        root.addView(statusText)
        addSpace(root, 15)

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 15, 15, 15)
            setBackgroundColor(panel)
        }

        root.addView(resultBox)

        addResultLine("SMC ICT ANALYSIS", gold, 19f)
        addResultLine("Select market and press SCAN MARKET.", muted)

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateMarketSpinner()
                }
            }

        updateMarketSpinner()

        scanButton.setOnClickListener {
            scanMarket()
        }

        setContentView(scroll)
    }

    private fun spinnerAdapter(
        items: List<String>
    ): ArrayAdapter<String> {

        return object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            items
        ) {

            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return makeSpinnerText(items[position])
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return makeSpinnerText(items[position])
            }
        }.apply {
            setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }
    }

    private fun makeSpinnerText(value: String): TextView {

        return TextView(this).apply {
            text = value
            textSize = 15f
            setTextColor(white)
            setPadding(12, 14, 12, 14)
            setBackgroundColor(panel)
        }
    }

    private fun updateMarketSpinner() {

        val category =
            categorySpinner.selectedItem?.toString() ?: "ALL"

        visibleMarkets = if (category == "ALL") {
            instruments
        } else {
            instruments.filter {
                it.category == category
            }
        }

        marketSpinner.adapter = spinnerAdapter(
            visibleMarkets.map { it.label }
        )
    }

    private fun addLabel(
        parent: LinearLayout,
        text: String
    ) {

        val label = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
        }

        parent.addView(label)
        addSpace(parent, 5)
    }

    private fun addSpace(
        parent: LinearLayout,
        height: Int
    ) {

        val space = View(this)

        parent.addView(
            space,
            LinearLayout.LayoutParams(1, height)
        )
    }

    private fun addResultLine(
        text: String,
        color: Int = white,
        size: Float = 15f
    ) {

        val line = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, 7, 0, 7)
        }

        resultBox.addView(line)
    }

    private fun scanMarket() {

        if (visibleMarkets.isEmpty()) return

        val selectedIndex = marketSpinner.selectedItemPosition

        if (selectedIndex !in visibleMarkets.indices) return

        val instrument = visibleMarkets[selectedIndex]
        val timeframe = timeframeSpinner.selectedItem.toString()

        if (instrument.provider != "Binance") {
            showUnavailable(instrument)
            return
        }

        scanButton.isEnabled = false
        statusText.text = "Fetching live market data..."

        resultBox.removeAllViews()

        addResultLine("ANALYZING MARKET...", gold, 18f)
        addResultLine(
            "Liquidity • Structure • FVG • Order Block",
            muted
        )

        thread {

            try {

                val candles = getBinanceCandles(
                    instrument.symbol,
                    timeframe
                )

                val higherTimeframe =
                    getHigherTimeframe(timeframe)

                val higherCandles = try {
                    getBinanceCandles(
                        instrument.symbol,
                        higherTimeframe
                    )
                } catch (e: Exception) {
                    emptyList()
                }

                val result = analyzeSMC(
                    candles,
                    higherCandles
                )

                runOnUiThread {

                    displayResult(
                        instrument,
                        timeframe,
                        higherTimeframe,
                        result
                    )

                    scanButton.isEnabled = true
                    statusText.text = "Analysis completed"
                }

            } catch (e: Exception) {

                runOnUiThread {

                    resultBox.removeAllViews()

                    addResultLine(
                        "DATA ERROR",
                        red,
                        20f
                    )

                    addResultLine(
                        e.message ?: "Unable to fetch market data",
                        muted
                    )

                    statusText.text = "Scan failed"
                    scanButton.isEnabled = true
                }
            }
        }
    }

    private fun showUnavailable(
        instrument: Instrument
    ) {

        resultBox.removeAllViews()

        addResultLine(
            "DATA SOURCE NOT CONNECTED",
            gold,
            18f
        )

        addResultLine(
            "Market: ${instrument.label}",
            white
        )

        addResultLine(
            "Live provider is not connected for this market.",
            muted
        )

        addResultLine(
            "No fake BUY/SELL signal will be generated.",
            red
        )

        statusText.text = "Waiting for live data connection"
    }

    private fun getHigherTimeframe(
        timeframe: String
    ): String {

        return when (timeframe) {
            "1m" -> "5m"
            "5m" -> "15m"
            "15m" -> "1h"
            "1h" -> "4h"
            "4h" -> "1d"
            else -> "1w"
        }
    }

    private fun getBinanceCandles(
        symbol: String,
        timeframe: String
    ): List<Candle> {

        val address =
            "https://api.binance.com/api/v3/klines" +
                    "?symbol=$symbol" +
                    "&interval=$timeframe" +
                    "&limit=150"

        val connection =
            URL(address).openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000

        try {

            val code = connection.responseCode

            if (code != 200) {
                throw Exception("Binance HTTP error: $code")
            }

            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val array = org.json.JSONArray(response)
            val candles = mutableListOf<Candle>()

            for (i in 0 until array.length()) {

                val item = array.getJSONArray(i)

                candles.add(
                    Candle(
                        open = item.getString(1).toDouble(),
                        high = item.getString(2).toDouble(),
                        low = item.getString(3).toDouble(),
                        close = item.getString(4).toDouble()
                    )
                )
            }

            // Ignore the currently forming candle.
            val closedCandles = candles.dropLast(1)

            if (closedCandles.size < 40) {
                throw Exception("Not enough closed candles")
            }

            return closedCandles

        } finally {
            connection.disconnect()
        }
    }

    private fun analyzeSMC(
        candles: List<Candle>,
        higherCandles: List<Candle>
    ): SignalResult {

        if (candles.size < 40) {
            return waitResult(
                candles.lastOrNull()?.close ?: 0.0,
                "Insufficient candle data"
            )
        }

        val atr = calculateATR(candles)

        if (atr <= 0.0) {
            return waitResult(
                candles.last().close,
                "ATR calculation unavailable"
            )
        }

        val current = candles.last()
        val range = candles.takeLast(50)

        val rangeHigh = range.maxOf { it.high }
        val rangeLow = range.minOf { it.low }
        val midpoint = (rangeHigh + rangeLow) / 2.0

        val premiumDiscount =
            if (current.close < midpoint) {
                "DISCOUNT"
            } else {
                "PREMIUM"
            }

        val htfBias =
            getHigherTimeframeBias(higherCandles)

        val setup = findSequentialSetup(
            candles,
            atr
        )

        if (setup == null) {

            return waitResult(
                current.close,
                "No fresh complete sequence: Liquidity Sweep → BOS/CHoCH → FVG/OB → Retest"
            )
        }

        if (setup.bullish && premiumDiscount != "DISCOUNT") {

            return waitResult(
                current.close,
                "Bullish setup found, but price is not in discount."
            )
        }

        if (!setup.bullish && premiumDiscount != "PREMIUM") {

            return waitResult(
                current.close,
                "Bearish setup found, but price is not in premium."
            )
        }

        if (htfBias == "BEARISH" && setup.bullish) {

            return waitResult(
                current.close,
                "Higher timeframe bias is bearish. Bullish setup rejected."
            )
        }

        if (htfBias == "BULLISH" && !setup.bullish) {

            return waitResult(
                current.close,
                "Higher timeframe bias is bullish. Bearish setup rejected."
            )
        }

        val entry = current.close

        val stopLoss = if (setup.bullish) {
            setup.sweepExtreme - atr * 0.15
        } else {
            setup.sweepExtreme + atr * 0.15
        }

        val risk = abs(entry - stopLoss)

        if (risk <= 0.0 || risk > atr * 5.0) {

            return waitResult(
                current.close,
                "Risk distance is not suitable."
            )
        }

        val target1 = if (setup.bullish) {
            entry + risk * 1.5
        } else {
            entry - risk * 1.5
        }

        val target2 = if (setup.bullish) {
            entry + risk * 2.5
        } else {
            entry - risk * 2.5
        }

        val direction =
            if (setup.bullish) "BUY" else "SELL"

        return SignalResult(
            signal = direction,
            entry = entry,
            stopLoss = stopLoss,
            target1 = target1,
            target2 = target2,
            details =
                "Liquidity sweep confirmed.\n" +
                "${setup.structure} confirmed.\n" +
                "${setup.zone.type} retest confirmed.\n" +
                "Market location: $premiumDiscount\n" +
                "Higher timeframe bias: $htfBias"
        )
    }

    // Finds only recent liquidity sweeps.
    // A setup must have a later BOS and a retest on the latest closed candle.

    private fun findSequentialSetup(
        candles: List<Candle>,
        atr: Double
    ): Setup? {

        val last = candles.lastIndex

        if (last < 40) return null

        val start = max(15, last - 12)

        for (i in last - 2 downTo start) {

            val previousHigh = lastPivotHigh(candles, i)
            val previousLow = lastPivotLow(candles, i)

            val candle = candles[i]

            val bullishSweep =
                previousLow != null &&
                candle.low < previousLow &&
                candle.close > previousLow

            val bearishSweep =
                previousHigh != null &&
                candle.high > previousHigh &&
                candle.close < previousHigh

            if (bullishSweep) {

                val bos = findBullishBOS(
                    candles,
                    i,
                    atr
                )

                if (bos != null && bos < last) {

                    val zone = findBullishZone(
                        candles,
                        i,
                        bos
                    )

                    if (zone != null) {

                        val latest = candles.last()

                        val retest =
                            latest.low <= zone.high &&
                            latest.high >= zone.low

                        val rejection =
                            latest.close > latest.open &&
                            latest.close > zone.low

                        if (retest && rejection) {

                            val structure =
                                if (
                                    getStructureBias(candles, i) == "BEARISH"
                                ) {
                                    "Bullish CHoCH"
                                } else {
                                    "Bullish BOS"
                                }

                            return Setup(
                                true,
                                candle.low,
                                zone,
                                structure
                            )
                        }
                    }
                }
            }

            if (bearishSweep) {

                val bos = findBearishBOS(
                    candles,
                    i,
                    atr
                )

                if (bos != null && bos < last) {

                    val zone = findBearishZone(
                        candles,
                        i,
                        bos
                    )

                    if (zone != null) {

                        val latest = candles.last()

                        val retest =
                            latest.high >= zone.low &&
                            latest.low <= zone.high

                        val rejection =
                            latest.close < latest.open &&
                            latest.close < zone.high

                        if (retest && rejection) {

                            val structure =
                                if (
                                    getStructureBias(candles, i) == "BULLISH"
                                ) {
                                    "Bearish CHoCH"
                                } else {
                                    "Bearish BOS"
                                }

                            return Setup(
                                false,
                                candle.high,
                                zone,
                                structure
                            )
                        }
                    }
                }
            }
        }

        return null
    }

    // Estimates the structure bias from confirmed swing pivots.

    private fun getStructureBias(
        candles: List<Candle>,
        before: Int
    ): String {

        val highs = mutableListOf<Double>()
        val lows = mutableListOf<Double>()

        val start = max(2, before - 30)

        for (i in start until before - 2) {

            val high = candles[i].high
            val low = candles[i].low

            val pivotHigh =
                high > candles[i - 1].high &&
                high > candles[i - 2].high &&
                high >= candles[i + 1].high &&
                high >= candles[i + 2].high

            val pivotLow =
                low < candles[i - 1].low &&
                low < candles[i - 2].low &&
                low <= candles[i + 1].low &&
                low <= candles[i + 2].low

            if (pivotHigh) highs.add(high)
            if (pivotLow) lows.add(low)
        }

        if (highs.size < 2 || lows.size < 2) {
            return "NEUTRAL"
        }

        val higherHigh =
            highs.last() > highs[highs.lastIndex - 1]

        val higherLow =
            lows.last() > lows[lows.lastIndex - 1]

        val lowerHigh =
            highs.last() < highs[highs.lastIndex - 1]

        val lowerLow =
            lows.last() < lows[lows.lastIndex - 1]

        return when {
            higherHigh && higherLow -> "BULLISH"
            lowerHigh && lowerLow -> "BEARISH"
            else -> "NEUTRAL"
        }
    }

    private fun findBullishBOS(
        candles: List<Candle>,
        sweepIndex: Int,
        atr: Double
    ): Int? {

        val end = min(
            candles.lastIndex - 1,
            sweepIndex + 8
        )

        for (j in sweepIndex + 1..end) {

            val swingHigh = lastPivotHigh(candles, j)

            if (swingHigh == null) continue

            val candle = candles[j]
            val body = abs(candle.close - candle.open)

            val displacement =
                candle.close > candle.open &&
                body >= atr * 0.5

            if (
                candle.close > swingHigh &&
                displacement
            ) {
                return j
            }
        }

        return null
    }

    private fun findBearishBOS(
        candles: List<Candle>,
        sweepIndex: Int,
        atr: Double
    ): Int? {

        val end = min(
            candles.lastIndex - 1,
            sweepIndex + 8
        )

        for (j in sweepIndex + 1..end) {

            val swingLow = lastPivotLow(candles, j)

            if (swingLow == null) continue

            val candle = candles[j]
            val body = abs(candle.close - candle.open)

            val displacement =
                candle.close < candle.open &&
                body >= atr * 0.5

            if (
                candle.close < swingLow &&
                displacement
            ) {
                return j
            }
        }

        return null
    }

    private fun findBullishZone(
        candles: List<Candle>,
        sweepIndex: Int,
        bosIndex: Int
    ): Zone? {

        // Bullish Fair Value Gap
        if (bosIndex >= 2) {

            val first = candles[bosIndex - 2]
            val third = candles[bosIndex]

            if (third.low > first.high) {

                return Zone(
                    low = first.high,
                    high = third.low,
                    type = "Bullish FVG"
                )
            }
        }

        // Last bearish candle before bullish displacement.
        for (i in bosIndex - 1 downTo sweepIndex + 1) {

            val candle = candles[i]

            if (candle.close < candle.open) {

                return Zone(
                    low = candle.low,
                    high = candle.high,
                    type = "Bullish Order Block"
                )
            }
        }

        return null
    }

    private fun findBearishZone(
        candles: List<Candle>,
        sweepIndex: Int,
        bosIndex: Int
    ): Zone? {

        // Bearish Fair Value Gap
        if (bosIndex >= 2) {

            val first = candles[bosIndex - 2]
            val third = candles[bosIndex]

            if (third.high < first.low) {

                return Zone(
                    low = third.high,
                    high = first.low,
                    type = "Bearish FVG"
                )
            }
        }

        // Last bullish candle before bearish displacement.
        for (i in bosIndex - 1 downTo sweepIndex + 1) {

            val candle = candles[i]

            if (candle.close > candle.open) {

                return Zone(
                    low = candle.low,
                    high = candle.high,
                    type = "Bearish Order Block"
                )
            }
        }

        return null
    }

    private fun lastPivotHigh(
        candles: List<Candle>,
        before: Int
    ): Double? {

        for (i in before - 2 downTo max(2, before - 25)) {

            val value = candles[i].high

            val isPivot =
                value > candles[i - 1].high &&
                value > candles[i - 2].high &&
                value >= candles[i + 1].high &&
                value >= candles[i + 2].high

            if (isPivot) return value
        }

        return null
    }

    private fun lastPivotLow(
        candles: List<Candle>,
        before: Int
    ): Double? {

        for (i in before - 2 downTo max(2, before - 25)) {

            val value = candles[i].low

            val isPivot =
                value < candles[i - 1].low &&
                value < candles[i - 2].low &&
                value <= candles[i + 1].low &&
                value <= candles[i + 2].low

            if (isPivot) return value
        }

        return null
    }

    private fun calculateATR(
        candles: List<Candle>
    ): Double {

        val start = max(1, candles.size - 15)
        val values = mutableListOf<Double>()

        for (i in start until candles.size) {

            val current = candles[i]
            val previousClose = candles[i - 1].close

            val trueRange = max(
                current.high - current.low,
                max(
                    abs(current.high - previousClose),
                    abs(current.low - previousClose)
                )
            )

            values.add(trueRange)
        }

        return values.average()
    }

    private fun getHigherTimeframeBias(
        candles: List<Candle>
    ): String {

        if (candles.size < 15) return "NEUTRAL"

        val recent = candles.takeLast(5)
        val previous = candles.dropLast(5).takeLast(5)

        if (previous.isEmpty()) return "NEUTRAL"

        val recentHigh = recent.maxOf { it.high }
        val recentLow = recent.minOf { it.low }

        val previousHigh = previous.maxOf { it.high }
        val previousLow = previous.minOf { it.low }

        return when {

            recentHigh > previousHigh &&
            recentLow > previousLow -> "BULLISH"

            recentHigh < previousHigh &&
            recentLow < previousLow -> "BEARISH"

            else -> "NEUTRAL"
        }
    }

    private fun waitResult(
        price: Double,
        reason: String
    ): SignalResult {

        return SignalResult(
            signal = "WAIT",
            entry = price,
            stopLoss = 0.0,
            target1 = 0.0,
            target2 = 0.0,
            details = reason
        )
    }

    private fun displayResult(
        instrument: Instrument,
        timeframe: String,
        higherTimeframe: String,
        result: SignalResult
    ) {

        resultBox.removeAllViews()

        val signalColor = when (result.signal) {
            "BUY" -> green
            "SELL" -> red
            else -> gold
        }

        addResultLine(
            "SMC ICT SIGNAL",
            gold,
            19f
        )

        addResultLine(
            "Market: ${instrument.label}",
            white
        )

        addResultLine(
            "Symbol: ${instrument.symbol}",
            muted
        )

        addResultLine(
            "Timeframe: $timeframe",
            white
        )

        addResultLine(
            "Higher Timeframe: $higherTimeframe",
            white
        )

        addResultLine(
            "Data Source: Binance Live",
            green
        )

        addSpace(resultBox, 8)

        addResultLine(
            "SIGNAL: ${result.signal}",
            signalColor,
            25f
        )

        addResultLine(
            "Entry Price: ${formatPrice(result.entry)}",
            white
        )

        if (result.signal != "WAIT") {

            addResultLine(
                "Stop Loss: ${formatPrice(result.stopLoss)}",
                red
            )

            addResultLine(
                "Target 1: ${formatPrice(result.target1)}",
                green
            )

            addResultLine(
                "Target 2: ${formatPrice(result.target2)}",
                green
            )

        } else {

            addResultLine("Stop Loss: --", muted)
            addResultLine("Target 1: --", muted)
            addResultLine("Target 2: --", muted)
        }

        addSpace(resultBox, 8)

        addResultLine(
            "ANALYSIS",
            gold,
            17f
        )

        addResultLine(
            result.details,
            muted
        )

        addSpace(resultBox, 10)

        addResultLine(
            "IMPORTANT: Experimental rule-based SMC/ICT analysis. " +
                    "Signals are not guaranteed. Always verify risk and market conditions.",
            gold,
            12f
        )
    }

    private fun formatPrice(value: Double): String {

        return String.format(
            Locale.US,
            "%.8f",
            value
        ).trimEnd('0').trimEnd('.')
    }
}