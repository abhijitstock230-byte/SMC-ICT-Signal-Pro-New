package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONArray
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Instrument(
    val label: String,
    val category: String,
    val symbol: String,
    val provider: String
)

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val closeTime: Long
)

data class SignalResult(
    val signal: String,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val details: String
)

data class Setup(
    val bullish: Boolean,
    val sweepIndex: Int,
    val sweepLevel: Double,
    val bosIndex: Int,
    val zoneIndex: Int,
    val zoneLow: Double,
    val zoneHigh: Double,
    val zoneType: String
)

class MainActivity : Activity() {

    private val bg = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(21, 29, 49)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 196, 220)
    private val green = Color.rgb(53, 211, 154)
    private val red = Color.rgb(255, 101, 119)
    private val gold = Color.rgb(255, 200, 87)

    private lateinit var categorySpinner: Spinner
    private lateinit var marketSpinner: Spinner
    private lateinit var timeframeSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button

    private val categories = listOf(
        "ALL", "INDIA", "CRYPTO", "FOREX", "METALS"
    )

    private val instruments = listOf(
        Instrument("NIFTY", "INDIA", "NIFTY", "Not connected"),
        Instrument("BANKNIFTY", "INDIA", "BANKNIFTY", "Not connected"),
        Instrument("SENSEX", "INDIA", "SENSEX", "Not connected"),
        Instrument("FINNIFTY", "INDIA", "FINNIFTY", "Not connected"),
        Instrument("MIDCPNIFTY", "INDIA", "MIDCPNIFTY", "Not connected"),

        Instrument("BTC / USDT", "CRYPTO", "BTCUSDT", "Binance"),
        Instrument("ETH / USDT", "CRYPTO", "ETHUSDT", "Binance"),
        Instrument("BNB / USDT", "CRYPTO", "BNBUSDT", "Binance"),
        Instrument("SOL / USDT", "CRYPTO", "SOLUSDT", "Binance"),
        Instrument("XRP / USDT", "CRYPTO", "XRPUSDT", "Binance"),
        Instrument("DOGE / USDT", "CRYPTO", "DOGEUSDT", "Binance"),
        Instrument("1000PEPE / USDT", "CRYPTO", "1000PEPEUSDT", "Binance"),
        Instrument("PAXG / USDT", "CRYPTO", "PAXGUSDT", "Binance"),
        Instrument("ZEC / USDT", "CRYPTO", "ZECUSDT", "Binance"),
        Instrument("TRX / USDT", "CRYPTO", "TRXUSDT", "Binance"),

        Instrument("EUR / USD", "FOREX", "EURUSD", "Not connected"),
        Instrument("GBP / USD", "FOREX", "GBPUSD", "Not connected"),
        Instrument("USD / JPY", "FOREX", "USDJPY", "Not connected"),

        Instrument("GOLD (XAUUSD)", "METALS", "XAUUSD", "Not connected"),
        Instrument("SILVER (XAGUSD)", "METALS", "XAGUSD", "Not connected")
    )

    private var visibleMarkets = instruments

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
    }

    private fun buildUI() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(18, 20, 18, 20)
        root.setBackgroundColor(bg)

        val scroll = ScrollView(this)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "SMC ICT SIGNAL PRO"
        title.textSize = 25f
        title.setTextColor(white)
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "SMART MONEY CONCEPTS • ICT SCANNER"
        subtitle.textSize = 12f
        subtitle.setTextColor(gold)
        subtitle.gravity = Gravity.CENTER
        subtitle.setPadding(0, 6, 0, 22)
        root.addView(subtitle)

        addLabel(root, "MARKET CATEGORY")
        categorySpinner = createSpinner(categories)
        root.addView(categorySpinner)

        addLabel(root, "SELECT MARKET")
        marketSpinner = createSpinner(emptyList())
        root.addView(marketSpinner)

        addLabel(root, "TIMEFRAME")
        timeframeSpinner = createSpinner(
            listOf("1m", "5m", "15m", "1h", "4h", "1d")
        )
        root.addView(timeframeSpinner)

        statusText = TextView(this)
        statusText.text = "Ready • Select a crypto market"
        statusText.textSize = 13f
        statusText.setTextColor(muted)
        statusText.gravity = Gravity.CENTER
        statusText.setPadding(5, 18, 5, 18)
        root.addView(statusText)

        scanButton = Button(this)
        scanButton.text = "SCAN MARKET"
        scanButton.textSize = 16f
        scanButton.setTextColor(Color.BLACK)
        scanButton.setBackgroundColor(gold)

        root.addView(
            scanButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                55
            )
        )

        resultBox = LinearLayout(this)
        resultBox.orientation = LinearLayout.VERTICAL
        resultBox.setPadding(14, 14, 14, 14)
        resultBox.setBackgroundColor(panel)

        val resultParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        resultParams.topMargin = 20
        root.addView(resultBox, resultParams)

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateMarkets(categories[position])
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        scanButton.setOnClickListener {
            scanMarket()
        }

        updateMarkets("ALL")
        setContentView(scroll)
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        val label = TextView(this)
        label.text = text
        label.textSize = 13f
        label.setTextColor(white)
        label.typeface = Typeface.DEFAULT_BOLD
        label.setPadding(2, 13, 2, 6)
        parent.addView(label)
    }

    private fun createSpinner(items: List<String>): Spinner {
        val spinner = Spinner(this)
        setSpinnerItems(spinner, items)
        return spinner
    }

    private fun setSpinnerItems(
        spinner: Spinner,
        items: List<String>
    ) {
        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            items
        ) {
            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val view = super.getView(position, convertView, parent)
                (view as TextView).setTextColor(white)
                view.textSize = 15f
                return view
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val view = super.getDropDownView(
                    position,
                    convertView,
                    parent
                )
                (view as TextView).setTextColor(white)
                view.setBackgroundColor(panel)
                view.textSize = 15f
                return view
            }
        }

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spinner.adapter = adapter
        spinner.setBackgroundColor(panel)
    }

    private fun updateMarkets(category: String) {
        visibleMarkets = if (category == "ALL") {
            instruments
        } else {
            instruments.filter { it.category == category }
        }

        setSpinnerItems(
            marketSpinner,
            visibleMarkets.map { it.label }
        )
    }

    private fun scanMarket() {
        val position = marketSpinner.selectedItemPosition

        if (position !in visibleMarkets.indices) {
            showMessage("Please select a market")
            return
        }

        val instrument = visibleMarkets[position]
        val timeframe = timeframeSpinner.selectedItem.toString()

        if (instrument.provider != "Binance") {
            showMessage(
                "WAIT\n\n" +
                "${instrument.label}\n\n" +
                "Live data feed is not connected for this market.\n" +
                "Crypto markets currently use Binance data."
            )
            return
        }

        scanButton.isEnabled = false
        scanButton.text = "SCANNING..."
        statusText.text = "Fetching live market data..."

        thread {
            try {
                val candles = fetchCandles(
                    instrument.symbol,
                    timeframe
                )

                val result = calculateSignal(candles)

                runOnUiThread {
                    showSignal(instrument, timeframe, result)
                    scanButton.isEnabled = true
                    scanButton.text = "SCAN MARKET"
                    statusText.text = "Scan completed • Binance"
                }

            } catch (e: Exception) {
                runOnUiThread {
                    showMessage(
                        "Unable to fetch market data.\n\n" +
                        "Check internet connection and try again."
                    )
                    scanButton.isEnabled = true
                    scanButton.text = "SCAN MARKET"
                    statusText.text = "Data connection error"
                }
            }
        }
    }

    private fun fetchCandles(
        symbol: String,
        timeframe: String
    ): List<Candle> {

        val url = URL(
            "https://api.binance.com/api/v3/klines" +
            "?symbol=$symbol&interval=$timeframe&limit=150"
        )

        val connection =
            url.openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000

        try {
            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val array = JSONArray(response)
            val candles = mutableListOf<Candle>()

            for (i in 0 until array.length()) {
                val row = array.getJSONArray(i)

                candles.add(
                    Candle(
                        open = row.getString(1).toDouble(),
                        high = row.getString(2).toDouble(),
                        low = row.getString(3).toDouble(),
                        close = row.getString(4).toDouble(),
                        closeTime = row.getLong(6)
                    )
                )
            }

            // Remove currently forming candle.
            val now = System.currentTimeMillis()

            return candles.filter {
                it.closeTime < now
            }

        } finally {
            connection.disconnect()
        }
    }

    private fun calculateSignal(
        candles: List<Candle>
    ): SignalResult {

        if (candles.size < 40) {
            return waitResult(
                candles.lastOrNull()?.close ?: 0.0,
                "Not enough candle data."
            )
        }

        val bullish = findSetup(candles, true)
        val bearish = findSetup(candles, false)

        val setup = when {
            bullish != null && bearish == null -> bullish
            bearish != null && bullish == null -> bearish
            else -> null
        }

        if (setup == null) {
            return waitResult(
                candles.last().close,
                "No confirmed liquidity sweep, BOS and retest setup."
            )
        }

        val last = candles.last()
        val atr = calculateAtr(candles)

        if (atr <= 0.0) {
            return waitResult(last.close, "ATR calculation unavailable.")
        }

        val entry = last.close

        val stopLoss = if (setup.bullish) {
            min(setup.sweepLevel, setup.zoneLow) - atr * 0.15
        } else {
            max(setup.sweepLevel, setup.zoneHigh) + atr * 0.15
        }

        val risk = abs(entry - stopLoss)

        if (risk <= 0.0) {
            return waitResult(entry, "Invalid risk calculation.")
        }

        val target1: Double
        val target2: Double

        if (setup.bullish) {
            target1 = entry + risk * 2.0
            target2 = entry + risk * 3.0
        } else {
            target1 = entry - risk * 2.0
            target2 = entry - risk * 3.0
        }

        val signal = if (setup.bullish) "BUY" else "SELL"

        val details =
            "Liquidity Sweep confirmed\n" +
            "Break of Structure confirmed\n" +
            "Displacement / zone retest confirmed\n" +
            "Entry zone: ${setup.zoneType}\n" +
            "Risk reward: 1:2 / 1:3"

        return SignalResult(
            signal,
            entry,
            stopLoss,
            target1,
            target2,
            details
        )
    }

    private fun findSetup(
        candles: List<Candle>,
        bullish: Boolean
    ): Setup? {

        val lastIndex = candles.lastIndex
        val firstSweep = max(12, lastIndex - 18)

        for (sweepIndex in lastIndex - 2 downTo firstSweep) {

            val start = max(0, sweepIndex - 10)
            val previous = candles.subList(start, sweepIndex)

            if (previous.isEmpty()) continue

            val level = if (bullish) {
                previous.minOf { it.low }
            } else {
                previous.maxOf { it.high }
            }

            val sweepCandle = candles[sweepIndex]

            val isSweep = if (bullish) {
                sweepCandle.low < level &&
                sweepCandle.close > level
            } else {
                sweepCandle.high > level &&
                sweepCandle.close < level
            }

            if (!isSweep) continue

            // Find structure break after the liquidity sweep.
            var bosIndex = -1

            val structureStart = max(0, sweepIndex - 10)

            val structureLevel = if (bullish) {
                candles.subList(structureStart, sweepIndex)
                    .maxOf { it.high }
            } else {
                candles.subList(structureStart, sweepIndex)
                    .minOf { it.low }
            }

            for (i in sweepIndex + 1..lastIndex) {
                val candle = candles[i]

                val displacement = abs(
                    candle.close - candle.open
                )

                val averageRange = calculateAtr(
                    candles.subList(max(0, i - 10), i + 1)
                )

                val strongMove = averageRange > 0.0 &&
                    displacement >= averageRange * 0.45

                val brokeStructure = if (bullish) {
                    candle.close > structureLevel
                } else {
                    candle.close < structureLevel
                }

                if (brokeStructure && strongMove) {
                    bosIndex = i
                    break
                }
            }

            if (bosIndex == -1 || bosIndex >= lastIndex) {
                continue
            }

            // Search for a Fair Value Gap after BOS.
            var zoneIndex = -1
            var zoneLow = 0.0
            var zoneHigh = 0.0
            var zoneType = ""

            val fvgStart = max(
                sweepIndex + 2,
                bosIndex - 1
            )

            val fvgEnd = min(lastIndex - 1, bosIndex + 3)

            if (fvgStart <= fvgEnd) {
                for (i in fvgStart..fvgEnd) {

                    val first = candles[i - 2]
                    val third = candles[i]

                    if (bullish &&
                        third.low > first.high
                    ) {
                        zoneIndex = i
                        zoneLow = first.high
                        zoneHigh = third.low
                        zoneType = "Bullish FVG"
                        break
                    }

                    if (!bullish &&
                        third.high < first.low
                    ) {
                        zoneIndex = i
                        zoneLow = third.high
                        zoneHigh = first.low
                        zoneType = "Bearish FVG"
                        break
                    }
                }
            }

            // If no FVG is found, use a simple opposite-candle OB.
            if (zoneIndex == -1) {

                for (i in bosIndex - 1 downTo sweepIndex + 1) {
                    val candle = candles[i]

                    val opposite = if (bullish) {
                        candle.close < candle.open
                    } else {
                        candle.close > candle.open
                    }

                    if (opposite) {
                        zoneIndex = i
                        zoneLow = candle.low
                        zoneHigh = candle.high
                        zoneType = if (bullish) {
                            "Bullish Order Block"
                        } else {
                            "Bearish Order Block"
                        }
                        break
                    }
                }
            }

            if (zoneIndex == -1) continue

            // The retest must happen after the zone was created.
            if (lastIndex <= zoneIndex) continue

            val last = candles[lastIndex]

            val touchedZone =
                last.low <= zoneHigh &&
                last.high >= zoneLow

            val rejection = if (bullish) {
                last.close > last.open &&
                last.close > zoneHigh
            } else {
                last.close < last.open &&
                last.close < zoneLow
            }

            if (touchedZone && rejection) {
                return Setup(
                    bullish,
                    sweepIndex,
                    level,
                    bosIndex,
                    zoneIndex,
                    zoneLow,
                    zoneHigh,
                    zoneType
                )
            }
        }

        return null
    }

    private fun calculateAtr(
        candles: List<Candle>
    ): Double {

        if (candles.size < 2) return 0.0

        val start = max(1, candles.size - 14)
        var total = 0.0
        var count = 0

        for (i in start until candles.size) {
            val current = candles[i]
            val previous = candles[i - 1]

            val range = max(
                current.high - current.low,
                max(
                    abs(current.high - previous.close),
                    abs(current.low - previous.close)
                )
            )

            total += range
            count++
        }

        return if (count > 0) total / count else 0.0
    }

    private fun waitResult(
        price: Double,
        reason: String
    ): SignalResult {
        return SignalResult(
            "WAIT",
            price,
            0.0,
            0.0,
            0.0,
            reason
        )
    }

    private fun showSignal(
        instrument: Instrument,
        timeframe: String,
        result: SignalResult
    ) {

        resultBox.removeAllViews()

        addResultText(
            "MARKET: ${instrument.label}",
            white,
            17f
        )

        addResultText(
            "TIMEFRAME: $timeframe",
            white,
            15f
        )

        val signalColor = when (result.signal) {
            "BUY" -> green
            "SELL" -> red
            else -> gold
        }

        addResultText(
            "SIGNAL: ${result.signal}",
            signalColor,
            25f
        )

        addResultText(
            "Entry Price: ${formatPrice(result.entry)}",
            white,
            17f
        )

        if (result.signal != "WAIT") {

            addResultText(
                "Stop Loss: ${formatPrice(result.stopLoss)}",
                red,
                17f
            )

            addResultText(
                "Target 1: ${formatPrice(result.target1)}",
                green,
                17f
            )

            addResultText(
                "Target 2: ${formatPrice(result.target2)}",
                green,
                17f
            )
        } else {
            addResultText(
                "SL / Targets: Not available",
                muted,
                14f
            )
        }

        addResultText(
            "\nSMC / ICT ANALYSIS",
            gold,
            15f
        )

        addResultText(
            result
.details,
            muted,
            14f
        )

        addResultText(
            "\nRULE-BASED PROTOTYPE • NOT FINANCIAL ADVICE",
            gold,
            10f
        )
    }

    private fun addResultText(
        text: String,
        color: Int,
        size: Float
    ) {
        val view = TextView(this)
        view.text = text
        view.setTextColor(color)
        view.textSize = size
        view.setPadding(4, 7, 4, 7)

        if (size >= 17f) {
            view.typeface = Typeface.DEFAULT_BOLD
        }

        resultBox.addView(view)
    }

    private fun showMessage(message: String) {
        resultBox.removeAllViews()
        addResultText(message, gold, 16f)
    }

    private fun formatPrice(value: Double): String {
        if (!value.isFinite()) return "--"

        val decimals = when {
            value >= 1000 -> 2
            value >= 1 -> 4
            value >= 0.01 -> 6
            else -> 10
        }

        return String.format(
            Locale.US,
            "%.${decimals}f",
            value
        )
    }
}