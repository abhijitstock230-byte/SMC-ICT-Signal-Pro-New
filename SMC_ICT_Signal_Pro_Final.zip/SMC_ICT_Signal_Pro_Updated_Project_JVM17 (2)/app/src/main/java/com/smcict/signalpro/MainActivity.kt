package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONArray
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Instrument(
    val label: String,
    val category: String,
    val symbol: String,
    val provider: String
)

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

data class SignalResult(
    val signal: String,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val details: String
)

class MainActivity : Activity() {

    private val background = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(21, 29, 49)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 196, 220)
    private val green = Color.rgb(53, 211, 154)
    private val red = Color.rgb(255, 101, 119)
    private val gold = Color.rgb(255, 200, 87)

    private lateinit var categorySpinner: Spinner
    private lateinit var marketSpinner: Spinner
    private lateinit var timeframeSpinner: Spinner
    private lateinit var resultBox: LinearLayout
    private lateinit var statusText: TextView

    private val handler = Handler(Looper.getMainLooper())

    private val categories = listOf(
        "ALL", "INDIA", "CRYPTO", "FOREX", "METALS"
    )

    private val timeframes = listOf(
        "1m", "5m", "15m", "1h", "4h", "1d"
    )

    private val instruments = listOf(
        Instrument("NIFTY 50", "INDIA", "NIFTY", "Not connected"),
        Instrument("BANK NIFTY", "INDIA", "BANKNIFTY", "Not connected"),
        Instrument("SENSEX", "INDIA", "SENSEX", "Not connected"),
        Instrument("FINNIFTY", "INDIA", "FINNIFTY", "Not connected"),
        Instrument("MIDCAP NIFTY", "INDIA", "MIDCPNIFTY", "Not connected"),

        Instrument("BTC / USDT", "CRYPTO", "BTCUSDT", "Binance"),
        Instrument("ETH / USDT", "CRYPTO", "ETHUSDT", "Binance"),
        Instrument("BNB / USDT", "CRYPTO", "BNBUSDT", "Binance"),
        Instrument("SOL / USDT", "CRYPTO", "SOLUSDT", "Binance"),
        Instrument("XRP / USDT", "CRYPTO", "XRPUSDT", "Binance"),
        Instrument("DOGE / USDT", "CRYPTO", "DOGEUSDT", "Binance"),
        Instrument("1000PEPE / USDT", "CRYPTO", "1000PEPEUSDT", "Binance"),
        Instrument("PAXG / USDT", "CRYPTO", "PAXGUSDT", "Binance"),
        Instrument("ZEC / USDT", "CRYPTO", "ZECUSDT", "Binance"),
        Instrument("TRX / USDT", "CRYPTO", "TRXUSDT", "Binance"),

        Instrument("EUR / USD", "FOREX", "EURUSD", "Not connected"),
        Instrument("GBP / USD", "FOREX", "GBPUSD", "Not connected"),
        Instrument("USD / JPY", "FOREX", "USDJPY", "Not connected"),

        Instrument("GOLD XAU / USD", "METALS", "XAUUSD", "Not connected"),
        Instrument("SILVER XAG / USD", "METALS", "XAGUSD", "Not connected")
    )

    private var visibleMarkets = instruments
    private var selectedTimeframe = "15m"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = background
        window.navigationBarColor = background

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "SMC ICT SIGNAL PRO"
            textSize = 23f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWidthWrap())

        val subtitle = TextView(this).apply {
            text = "MARKET SCANNER  •  RULE-BASED PROTOTYPE"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 18)
        }
        root.addView(subtitle, matchWidthWrap())

        addLabel(root, "MARKET CATEGORY")

        categorySpinner = Spinner(this)
        setupSpinner(categorySpinner, categories)
        root.addView(categorySpinner, matchWidthWrap())

        addSpace(root, 12)
        addLabel(root, "SELECT MARKET")

        marketSpinner = Spinner(this)
        root.addView(marketSpinner, matchWidthWrap())

        addSpace(root, 12)
        addLabel(root, "TIMEFRAME")

        timeframeSpinner = Spinner(this)
        setupSpinner(timeframeSpinner, timeframes)
        root.addView(timeframeSpinner, matchWidthWrap())

        addSpace(root, 16)

        statusText = TextView(this).apply {
            text = "Ready • Select a crypto market"
            textSize = 13f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
        }
        root.addView(statusText, matchWidthWrap())

        val scanButton = Button(this).apply {
            text = "SCAN MARKET"
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(green)
            setOnClickListener { scanSelectedMarket() }
        }
        root.addView(scanButton, matchWidthWrap())

        addSpace(root, 16)

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(panel)
        }
        root.addView(
            resultBox,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        setContentView(root)

        updateMarkets("ALL")

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateMarkets(categories[position])
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        timeframeSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    selectedTimeframe = timeframes[position]
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        showWelcome()
    }    private fun matchWidthWrap(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(muted)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(2, 5, 2, 5)
        }
        parent.addView(label, matchWidthWrap())
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        val space = View(this)
        parent.addView(
            space,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                height
            )
        )
    }

    private fun setupSpinner(spinner: Spinner, items: List<String>) {
        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            items
        ) {
            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val text = TextView(this@MainActivity).apply {
                    this.text = getItem(position) ?: ""
                    textSize = 15f
                    setTextColor(white)
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(panel)
                }
                return text
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                val text = TextView(this@MainActivity).apply {
                    this.text = getItem(position) ?: ""
                    textSize = 15f
                    setTextColor(white)
                    setPadding(16, 14, 16, 14)
                    setBackgroundColor(panel)
                }
                return text
            }
        }

        spinner.adapter = adapter
        spinner.setBackgroundColor(panel)
    }

    private fun updateMarkets(category: String) {
        visibleMarkets = if (category == "ALL") {
            instruments
        } else {
            instruments.filter { it.category == category }
        }

        val adapter = object : ArrayAdapter<Instrument>(
            this,
            android.R.layout.simple_spinner_item,
            visibleMarkets
        ) {
            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return makeMarketText(position)
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return makeMarketText(position)
            }

            private fun makeMarketText(position: Int): TextView {
                return TextView(this@MainActivity).apply {
                    text = visibleMarkets[position].label
                    textSize = 15f
                    setTextColor(white)
                    setPadding(16, 14, 16, 14)
                    setBackgroundColor(panel)
                }
            }
        }

        marketSpinner.adapter = adapter
        if (visibleMarkets.isNotEmpty()) {
            marketSpinner.setSelection(0)
        }
        statusText.text = "${visibleMarkets.size} markets available"
    }

    private fun showWelcome() {
        resultBox.removeAllViews()
        addResultText("Welcome to SMC ICT Signal Pro", gold, 18f)
        addResultText(
            "Choose a market and timeframe, then tap SCAN MARKET.",
            white,
            14f
        )
        addResultText(
            "Live candle data is currently connected only for supported Binance crypto pairs.",
            muted,
            12f
        )
        addResultText(
            "India, Forex and Metals live feeds are not connected yet.",
            muted,
            12f
        )
        addResultText(
            "Signals are a basic rule-based prototype, not a complete SMC/ICT model.",
            gold,
            12f
        )
    }

    private fun scanSelectedMarket() {
        if (visibleMarkets.isEmpty()) return

        val instrument = visibleMarkets[marketSpinner.selectedItemPosition]

        if (instrument.provider != "Binance") {
            showUnavailable(instrument)
            return
        }

        statusText.text = "Fetching live candles..."
        resultBox.removeAllViews()
        addResultText("Scanning ${instrument.label}", gold, 18f)
        addResultText("Please wait...", muted, 14f)

        thread {
            try {
                val candles = fetchCandles(
                    instrument.symbol,
                    selectedTimeframe
                )
                val result = calculateSignal(candles)

                runOnUiThread {
                    showSignal(instrument, result)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Data fetch failed"
                    resultBox.removeAllViews()
                    addResultText("Unable to fetch market data.", red, 16f)
                    addResultText(
                        e.message ?: "Please check your internet connection.",
                        muted,
                        12f
                    )
                }
            }
        }
    }

    private fun showUnavailable(instrument: Instrument) {
        statusText.text = "Live feed not connected"
        resultBox.removeAllViews()
        addResultText(instrument.label, gold, 20f)
        addResultText("LIVE DATA NOT CONNECTED", red, 16f)
        addResultText(
            "Provider: ${instrument.provider}",
            muted,
            14f
        )
        addResultText(
            "No live BUY/SELL signal is available for this market yet.",
            white,
            13f
        )
    }

    private fun fetchCandles(
        symbol: String,
        timeframe: String
    ): List<Candle> {
        val url = URL(
            "https://api.binance.com/api/v3/klines" +
                "?symbol=$symbol&interval=$timeframe&limit=100"
        )

        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 12000

        try {
            if (connection.responseCode != 200) {
                throw Exception("Binance API HTTP ${connection.responseCode}")
            }

            val response = connection.inputStream.bufferedReader().use {
                it.readText()
            }

            val array = JSONArray(response)
            val candles = mutableListOf<Candle>()

            for (i in 0 until array.length()) {
                val item = array.getJSONArray(i)
                candles.add(
                    Candle(
                        open = item.getString(1).toDouble(),
                        high = item.getString(2).toDouble(),
                        low = item.getString(3).toDouble(),
                        close = item.getString(4).toDouble()
                    )
                )
            }

            if (candles.size < 30) {
                throw Exception("Not enough candle data")
            }

            return candles
        } finally {
            connection.disconnect()
        }
    }

    private fun calculateSignal(candles: List<Candle>): SignalResult {
        val closes = candles.map { it.close }
        val last = candles.last()
        val previous = candles.dropLast(1)

        val ema9 = calculateEma(closes, 9)
        val ema21 = calculateEma(closes, 21)

        val recent = previous.takeLast(20)
        val previousHigh = recent.maxOf { it.high }
        val previousLow = recent.minOf { it.low }

        val atr = calculateAtr(candles, 14).coerceAtLeast(
            last.close * 0.001
        )

        val signal = when {
            ema9 > ema21 && last.close > previousHigh -> "BUY"
            ema9 < ema21 && last.close < previousLow -> "SELL"
            else -> "WAIT"
        }

        val entry = last.close

        val stopLoss = when (signal) {
            "BUY" -> entry - atr * 1.5
            "SELL" -> entry + atr * 1.5
            else -> 0.0
        }

        val target1 = when (signal) {
            "BUY" -> entry + atr * 2.0
            "SELL" -> entry - atr * 2.0
            else -> 0.0
        }

        val target2 = when (signal) {
            "BUY" -> entry + atr * 3.0
            "SELL" -> entry - atr * 3.0
            else -> 0.0
        }

        val details = when (signal) {
            "BUY" -> "EMA 9 above EMA 21 + 20-candle high breakout"
            "SELL" -> "EMA 9 below EMA 21 + 20-candle low breakout"
            else -> "No qualifying breakout condition"
        }

        return SignalResult(
            signal,
            entry,
            stopLoss,
            target1,
            target2,
            details
        )
    }

    private fun calculateEma(
        values: List<Double>,
        period: Int
    ): Double {
        val multiplier = 2.0 / (period + 1)
        var ema = values.take(period).average()

        for (i in period until values.size) {
            ema = (values[i] * multiplier) +
                (ema * (1.0 - multiplier))
        }

        return ema
    }

    private fun calculateAtr(
        candles: List<Candle>,
        period: Int
    ): Double {
        val ranges = mutableListOf<Double>()

        for (i in 1 until candles.size) {
            val current = candles[i]
            val previousClose = candles[i - 1].close

            val trueRange = max(
                current.high - current.low,
                max(
                    abs(current.high - previousClose),
                    abs(current.low - previousClose)
                )
            )

            ranges.add(trueRange)
        }

        return ranges.takeLast(period).average()
    }

    private fun showSignal(
        instrument: Instrument,
        result: SignalResult
    ) {
        statusText.text = "Live Binance candle data received"
        resultBox.removeAllViews()

        val signalColor = when (result.signal) {
            "BUY" -> green
            "SELL" -> red
            else -> gold
        }

        addResultText(instrument.label, white, 19f)
        addResultText("SIGNAL: ${result.signal}", signalColor, 25f)
        addResultText("Timeframe: $selectedTimeframe", muted, 13f)

        addSpace(resultBox, 8)

        addResultText(
            "Entry: ${formatPrice(result.entry)}",
            white,
            15f
        )

        if (result.signal != "WAIT") {
            addResultText(
                "Stop Loss: ${formatPrice(result.stopLoss)}",
                red,
                15f
            )
            addResultText(
                "Target 1: ${formatPrice(result.target1)}",
                green,
                15f
            )
            addResultText(
                "Target 2: ${formatPrice(result.target2)}",
                green,
                15f
            )
        } else {
            addResultText(
                "Entry / SL / Targets: Wait for a valid setup",
                muted,
                13f
            )
        }

        addSpace(resultBox, 8)
        addResultText("Reason: ${result.details}", muted, 12f)
        addResultText(
            "Data source: Binance public market API",
            muted,
            11f
        )
        addResultText(
            "Prototype only. Not financial advice.",
            gold,
            11f
        )
    }

    private fun formatPrice(value: Double): String {
        return String.format(java.util.Locale.US, "%.6f", value)
            .trimEnd('0')
            .trimEnd('.')
    }

    private fun addResultText(
        text: String,
        color: Int,
        size: Float
    ) {
        val view = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(2, 7, 2, 7)
        }
        resultBox.addView(view, matchWidthWrap())
    }
}