package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONArray
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Instrument(
    val label: String,
    val category: String,
    val symbol: String,
    val provider: String
)

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

data class SignalResult(
    val signal: String,
    val entry: Double?,
    val stopLoss: Double?,
    val target1: Double?,
    val target2: Double?,
    val details: String
)

data class Setup(
    val bullish: Boolean,
    val sweepIndex: Int,
    val bosIndex: Int,
    val zoneIndex: Int,
    val zoneLow: Double,
    val zoneHigh: Double,
    val zoneType: String,
    val sweepLevel: Double,
    val structureType: String
)

class MainActivity : Activity() {

    private val background = Color.rgb(11, 16, 32)
    private val panel = Color.rgb(21, 29, 49)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 196, 220)
    private val green = Color.rgb(53, 211, 154)
    private val red = Color.rgb(255, 101, 119)
    private val gold = Color.rgb(255, 200, 87)

    private lateinit var categorySpinner: Spinner
    private lateinit var marketSpinner: Spinner
    private lateinit var timeframeSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button

    private var selectedInstrument: Instrument? = null

    private val instruments = listOf(

        Instrument("BTC / USDT", "CRYPTO", "BTCUSDT", "Binance"),
        Instrument("ETH / USDT", "CRYPTO", "ETHUSDT", "Binance"),
        Instrument("BNB / USDT", "CRYPTO", "BNBUSDT", "Binance"),
        Instrument("SOL / USDT", "CRYPTO", "SOLUSDT", "Binance"),
        Instrument("XRP / USDT", "CRYPTO", "XRPUSDT", "Binance"),
        Instrument("DOGE / USDT", "CRYPTO", "DOGEUSDT", "Binance"),
        Instrument("1000PEPE / USDT", "CRYPTO", "1000PEPEUSDT", "Binance"),
        Instrument("PAXG / USDT", "CRYPTO", "PAXGUSDT", "Binance"),
        Instrument("ZEC / USDT", "CRYPTO", "ZECUSDT", "Binance"),
        Instrument("TRX / USDT", "CRYPTO", "TRXUSDT", "Binance"),

        Instrument("NIFTY", "INDIA", "NIFTY", "Not connected"),
        Instrument("BANKNIFTY", "INDIA", "BANKNIFTY", "Not connected"),
        Instrument("SENSEX", "INDIA", "SENSEX", "Not connected"),
        Instrument("FINNIFTY", "INDIA", "FINNIFTY", "Not connected"),
        Instrument("MIDCPNIFTY", "INDIA", "MIDCPNIFTY", "Not connected"),

        Instrument("EUR / USD", "FOREX", "EURUSD", "Not connected"),
        Instrument("GBP / USD", "FOREX", "GBPUSD", "Not connected"),
        Instrument("USD / JPY", "FOREX", "USDJPY", "Not connected"),

        Instrument("GOLD (XAUUSD)", "METALS", "XAUUSD", "Not connected"),
        Instrument("SILVER (XAGUSD)", "METALS", "XAGUSD", "Not connected")
    )

    private val timeframes = listOf(
        "1m", "5m", "15m", "1h", "4h", "1d"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
    }

    private fun buildUI() {

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 20)
            setBackgroundColor(background)
        }

        val scrollView = ScrollView(this)
        scrollView.addView(root)

        val title = TextView(this).apply {
            text = "SMC ICT SIGNAL PRO"
            textSize = 25f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "SMART MONEY CONCEPTS • ICT SCANNER V4"
            textSize = 12f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }

        root.addView(title)
        root.addView(subtitle)

        categorySpinner = Spinner(this)
        marketSpinner = Spinner(this)
        timeframeSpinner = Spinner(this)

        addLabel(root, "MARKET CATEGORY")
        root.addView(categorySpinner)

        addLabel(root, "SELECT MARKET")
        root.addView(marketSpinner)

        addLabel(root, "TIMEFRAME")
        root.addView(timeframeSpinner)

        val categories = listOf(
            "ALL", "INDIA", "CRYPTO", "FOREX", "METALS"
        )

        setSpinner(categorySpinner, categories)
        setSpinner(timeframeSpinner, timeframes)

        updateMarketList("ALL")

        categorySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    updateMarketList(categories[position])
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {}
            }

        statusText = TextView(this).apply {
            text = "Ready • Select a crypto market"
            textSize = 14f
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
        }

        root.addView(statusText)

        scanButton = Button(this).apply {
            text = "SCAN MARKET"
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
        }

        root.addView(
            scanButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 15, 15, 15)
            setBackgroundColor(panel)
        }

        val resultParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        resultParams.topMargin = 20

        root.addView(resultBox, resultParams)

        scanButton.setOnClickListener {
            scanMarket()
        }

        addView(scrollView)
    }

    private fun addView(view: View) {
        setContentView(view)
    }

    private fun addLabel(
        parent: LinearLayout,
        text: String
    ) {

        val label = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 12, 4, 6)
        }

        parent.addView(label)
    }

    private fun setSpinner(
        spinner: Spinner,
        items: List<String>
    ) {

        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            items
        ) {

            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                val view = super.getView(
                    position,
                    convertView,
                    parent
                ) as TextView

                view.setTextColor(white)
                view.textSize = 15f
                view.setPadding(12, 12, 12, 12)

                return view
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {

                val view = super.getDropDownView(
                    position,
                    convertView,
                    parent
                ) as TextView

                view.setTextColor(white)
                view.setBackgroundColor(panel)
                view.textSize = 15f
                view.setPadding(16, 14, 16, 14)

                return view
            }
        }

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        spinner.adapter = adapter
    }

    private fun updateMarketList(category: String) {

        val filtered = if (category == "ALL") {
            instruments
        } else {
            instruments.filter {
                it.category == category
            }
        }

        val labels = filtered.map { it.label }

        setSpinner(marketSpinner, labels)

        marketSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    selectedInstrument = filtered.getOrNull(position)
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) {}
            }
    }

    private fun scanMarket() {

        val instrument = selectedInstrument

        if (instrument == null) {
            showMessage("Please select a market.")
            return
        }

        if (instrument.provider != "Binance") {
            showMessage(
                "Live data is not connected for this market yet."
            )
            return
        }

        val timeframe = timeframeSpinner.selectedItem.toString()

        scanButton.isEnabled = false
        statusText.text = "Scanning ${instrument.label}..."
        resultBox.removeAllViews()

        thread {

            try {

                val candles = fetchCandles(
                    instrument.symbol,
                    timeframe
                )

                val result = calculateSignal(candles)

                runOnUiThread {

                    scanButton.isEnabled = true
                    statusText.text = "Scan completed"

                    showSignal(
                        instrument,
                        timeframe,
                        result
                    )
                }

            } catch (e: Exception) {

                runOnUiThread {

                    scanButton.isEnabled = true
                    statusText.text = "Scan failed"

                    showMessage(
                        "Data error: ${e.message ?: "Unknown error"}"
                    )
                }
            }
        }
    }

    private fun fetchCandles(
        symbol: String,
        timeframe: String
    ): List<Candle> {

        val url =
            "https://api.binance.com/api/v3/klines" +
            "?symbol=$symbol&interval=$timeframe&limit=200"

        val connection =
            URL(url).openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 15000
        connection.readTimeout = 15000

        try {

            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val json = JSONArray(response)
            val candles = mutableListOf<Candle>()

            val now = System.currentTimeMillis()

            for (i in 0 until json.length()) {

                val item = json.getJSONArray(i)
                val closeTime = item.getLong(6)

                // Ignore the currently forming candle.
                if (closeTime >= now) continue

                candles.add(
                    Candle(
                        open = item.getString(1).toDouble(),
                        high = item.getString(2).toDouble(),
                        low = item.getString(3).toDouble(),
                        close = item.getString(4).toDouble()
                    )
                )
            }

            if (candles.size < 60) {
                throw Exception("Not enough market candles")
            }

            return candles

        } finally {
            connection.disconnect()
        }
    }

    private fun calculateSignal(
        candles: List<Candle>
    ): SignalResult {

        if (candles.size < 60) {
            return waitResult(
                "Not enough candles for analysis."
            )
        }

        val bullishSetup = findSetup(candles, true)
        val bearishSetup = findSetup(candles, false)

        if (bullishSetup != null && bearishSetup != null) {
            return waitResult(
                "Conflicting bullish and bearish setups detected."
            )
        }

        val setup = bullishSetup ?: bearishSetup
            ?: return waitResult(
                "No confirmed liquidity sweep, BOS and zone retest."
            )

        val atr = calculateAtr(candles)

        if (atr <= 0.0) {
            return waitResult("ATR calculation unavailable.")
        }

        val last = candles.last()
        val entry = last.close

        val stopLoss = if (setup.bullish) {

            min(
                setup.sweepLevel,
                setup.zoneLow
            ) - atr * 0.20

        } else {

            max(
                setup.sweepLevel,
                setup.zoneHigh
            ) + atr * 0.20
        }

        val risk = abs(entry - stopLoss)

        if (risk <= 0.0 || risk > atr * 5.0) {
            return waitResult(
                "Risk distance is too large or invalid."
            )
        }

        if (setup.bullish && stopLoss >= entry) {
            return waitResult(
                "Invalid bullish stop-loss placement."
            )
        }

        if (!setup.bullish && stopLoss <= entry) {
            return waitResult(
                "Invalid bearish stop-loss placement."
            )
        }

        val target1 = if (setup.bullish) {
            entry + risk * 2.0
        } else {
            entry - risk * 2.0
        }

        val target2 = if (setup.bullish) {
            entry + risk * 3.0
        } else {
            entry - risk * 3.0
        }

        val signal = if (setup.bullish) {
            "BUY"
        } else {
            "SELL"
        }

        val details = buildString {

            appendLine("Setup: ${setup.structureType}")
            appendLine("Liquidity sweep: Confirmed")
            appendLine("Structure break: Confirmed")
            appendLine("Entry zone: ${setup.zoneType}")
            appendLine("Zone retest: Confirmed")
            appendLine("Risk-reward: 1:2 / 1:3")
        }

        return SignalResult(
            signal = signal,
            entry = entry,
            stopLoss = stopLoss,
            target1 = target1,
            target2 = target2,
            details = details
        )
    }

    private fun findSetup(
        candles: List<Candle>,
        bullish: Boolean
    ): Setup? {

        val lastIndex = candles.lastIndex

        val firstSweep = max(20, lastIndex - 9)
        val lastSweep = lastIndex - 3

        if (lastSweep < firstSweep) return null

        val atr = calculateAtr(candles)

        if (atr <= 0.0) return null

        var sweepIndex = -1
        var liquidityLevel = 0.0

        // Find a recent liquidity sweep.
        for (i in lastSweep downTo firstSweep) {

            val start = max(0, i - 20)
            val previous = candles.subList(start, i)

            if (previous.isEmpty()) continue

            if (bullish) {

                val previousLow = previous.minOf { it.low }

                if (
                    candles[i].low < previousLow &&
                    candles[i].close > previousLow
                ) {

                    sweepIndex = i
                    liquidityLevel = previousLow
                    break
                }

            } else {

                val previousHigh = previous.maxOf { it.high }

                if (
                    candles[i].high > previousHigh &&
                    candles[i].close < previousHigh
                ) {

                    sweepIndex = i
                    liquidityLevel = previousHigh
                    break
                }
            }
        }

        if (sweepIndex < 0) return null

        // Find confirmed market structure before the sweep.
        var structureLevel = Double.NaN

        val structureStart = max(2, sweepIndex - 25)

        for (
            i in sweepIndex - 2 downTo structureStart
        ) {

            if (bullish && isSwingHigh(candles, i)) {
                structureLevel = candles[i].high
                break
            }

            if (!bullish && isSwingLow(candles, i)) {
                structureLevel = candles[i].low
                break
            }
        }

        if (structureLevel.isNaN()) return null

        // Find displacement and BOS after the sweep.
        var bosIndex = -1

        for (
            i in sweepIndex + 1..min(
                lastIndex - 1,
                sweepIndex + 5
            )
        ) {

            val candle = candles[i]
            val body = abs(candle.close - candle.open)

            val displacement = body >= atr * 0.50

            val structureBreak = if (bullish) {

                candle.close > structureLevel &&
                    candle.close > candle.open

            } else {

                candle.close < structureLevel &&
                    candle.close < candle.open
            }

            if (displacement && structureBreak) {
                bosIndex = i
                break
            }
        }

        if (bosIndex < 0) return null

        // Search for Fair Value Gap after BOS.
        var zoneIndex = -1
        var zoneLow = 0.0
        var zoneHigh = 0.0
        var zoneType = ""

        val fvgStart = bosIndex + 1
        val fvgEnd = min(lastIndex - 1, bosIndex + 3)

        for (i in fvgStart..fvgEnd) {

            if (i < 2) continue

            val first = candles[i - 2]
            val middle = candles[i - 1]
            val third = candles[i]

            val middleBody = abs(
                middle.close - middle.open
            )

            if (middleBody < atr * 0.30) continue

            if (bullish) {

                if (
                    first.high < third.low &&
                    middle.close > middle.open
                ) {

                    zoneIndex = i
                    zoneLow = first.high
                    zoneHigh = third.low
                    zoneType = "Bullish FVG"
                    break
                }

            } else {

                if (
                    first.low > third.high &&
                    middle.close < middle.open
                ) {

                    zoneIndex = i
                    zoneLow = third.high
                    zoneHigh = first.low
                    zoneType = "Bearish FVG"
                    break
                }
            }
        }

        // If FVG is unavailable, use the last opposite candle as OB.
        if (zoneIndex < 0) {

            for (
                i in bosIndex - 1 downTo sweepIndex + 1
            ) {

                val candle = candles[i]

                val oppositeCandle = if (bullish) {
                    candle.close < candle.open
                } else {
                    candle.close > candle.open
                }

                if (oppositeCandle) {

                    zoneIndex = i
                    zoneLow = candle.low
                    zoneHigh = candle.high

                    zoneType = if (bullish) {
                        "Bullish Order Block"
                    } else {
                        "Bearish Order Block"
                    }

                    break
                }
            }
        }

        if (zoneIndex < 0) return null

        if (zoneHigh <= zoneLow) return null

        // Latest candle must retest and reject the zone.
        val last = candles[lastIndex]

        val touchedZone =
            last.low <= zoneHigh &&
            last.high >= zoneLow

        val rejection = if (bullish) {

            last.close > last.open &&
                last.close > zoneLow

        } else {

            last.close < last.open &&
                last.close < zoneHigh
        }

        // Measure distance from the correct zone boundary.
        val closeDistance = abs(
            last.close - if (bullish) zoneHigh else zoneLow
        )

        if (!touchedZone || !rejection) return null

        if (closeDistance > atr * 1.5) return null

        if (lastIndex - bosIndex > 7) return null

        return Setup(
            bullish = bullish,
            sweepIndex = sweepIndex,
            bosIndex = bosIndex,
            zoneIndex = zoneIndex,
            zoneLow = zoneLow,
            zoneHigh = zoneHigh,
            zoneType = zoneType,
            sweepLevel = liquidityLevel,
            structureType = if (bullish) {
                "Bullish CHoCH/BOS"
            } else {
                "Bearish CHoCH/BOS"
            }
        )
    }

    private fun isSwingHigh(
        candles: List<Candle>,
        index: Int
    ): Boolean {

        if (index < 2 || index + 2 >= candles.size) {
            return false
        }

        val value = candles[index].high

        return value > candles[index - 1].high &&
            value > candles[index - 2].high &&
            value > candles[index + 1].high &&
            value > candles[index + 2].high
    }

    private fun isSwingLow(
        candles: List<Candle>,
        index: Int
    ): Boolean {

        if (index < 2 || index + 2 >= candles.size) {
            return false
        }

        val value = candles[index].low

        return value < candles[index - 1].low &&
            value < candles[index - 2].low &&
            value < candles[index + 1].low &&
            value < candles[index + 2].low
    }

    private fun calculateAtr(
        candles: List<Candle>
    ): Double {

        if (candles.size < 15) return 0.0

        val start = max(1, candles.size - 14)

        val ranges = mutableListOf<Double>()

        for (i in start until candles.size) {

            val current = candles[i]
            val previous = candles[i - 1]

            val range1 = current.high - current.low
            val range2 = abs(current.high - previous.close)
            val range3 = abs(current.low - previous.close)

            ranges.add(
                max(range1, max(range2, range3))
            )
        }

        return if (ranges.isEmpty()) {
            0.0
        } else {
            ranges.average()
        }
    }

    private fun waitResult(
        reason: String
    ): SignalResult {

        return SignalResult(
            signal = "WAIT",
            entry = null,
            stopLoss = null,
            target1 = null,
            target2 = null,
            details = reason
        )
    }

    private fun showSignal(
        instrument: Instrument,
        timeframe: String,
        result: SignalResult
    ) {

        resultBox.removeAllViews()

        addResultText(
            "MARKET: ${instrument.label}",
            white,
            17f,
            true
        )

        addResultText(
            "TIMEFRAME: $timeframe",
            white,
            15f,
            true
        )

        addResultText(
            "SIGNAL: ${result.signal}",
            when (result.signal) {
                "BUY" -> green
                "SELL" -> red
                else -> gold
            },
            23f,
            true
        )

        if (
            result.signal == "BUY" ||
            result.signal == "SELL"
        ) {

            addResultText(
                "Entry Price: ${formatPrice(result.entry!!)}",
                white,
                17f,
                true
            )

            addResultText(
                "Stop Loss: ${formatPrice(result.stopLoss!!)}",
                red,
                16f,
                true
            )

            addResultText(
                "Target 1: ${formatPrice(result.target1!!)}",
                green,
                16f,
                true
            )

            addResultText(
                "Target 2: ${formatPrice(result.target2!!)}",
                green,
                16f,
                true
            )

        } else {

            addResultText(
                "Entry Price: Not available",
                muted,
                15f,
                false
            )

            addResultText(
                "Stop Loss: Not available",
                muted,
                15f,
                false
            )

            addResultText(
                "Target 1: Not available",
                muted,
                15f,
                false
            )

            addResultText(
                "Target 2: Not available",
                muted,
                15f,
                false
            )
        }

        addResultText(
            "ANALYSIS DETAILS",
            gold,
            16f,
            true
        )

        addResultText(
            result.details,
            white,
            14f,
            false
        )

        addResultText(
            "V4 RULE-BASED PROTOTYPE • NOT FINANCIAL ADVICE",
            muted,
            11f,
            false
        )
    }

    private fun addResultText(
        text: String,
        color: Int,
        size: Float,
        bold: Boolean
    ) {

        val textView = TextView(this).apply {

            this.text = text
            textSize = size
            setTextColor(color)

            if (bold) {
                typeface = Typeface.DEFAULT_BOLD
            }

            setPadding(5, 8, 5, 8)
        }

        resultBox.addView(textView)
    }

    private fun showMessage(message: String) {

        resultBox.removeAllViews()

        addResultText(
            message,
            gold,
            15f,
            true
        )
    }

    private fun formatPrice(value: Double): String {

        return String.format(
            Locale.US,
            "%.8f",
            value
        ).trimEnd('0').trimEnd('.')
    }
}