package com.smcict.signalpro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var market: Spinner
    private lateinit var timeframe: Spinner
    private lateinit var resultBox: TextView
    private lateinit var status: TextView
    private lateinit var scanButton: Button

    private val df = DecimalFormat("#,##0.########")

    private val instruments = listOf(
        "BTC/USDT",
        "ETH/USDT",
        "BNB/USDT",
        "SOL/USDT",
        "XRP/USDT",
        "DOGE/USDT"
    )

    private data class Candle(
        val open: Double,
        val high: Double,
        val low: Double,
        val close: Double
    )

    private data class Analysis(
        val bullish: Boolean,
        val bearish: Boolean,
        val description: String
    )

    private data class Signal(
        val direction: String,
        val entry: Double,
        val stop: Double,
        val target1: Double,
        val target2: Double,
        val target3: Double,
        val details: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(10, 18, 32)
        window.navigationBarColor = Color.rgb(10, 18, 32)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 18)
            setBackgroundColor(Color.rgb(10, 18, 32))
        }

        fun makeText(
            value: String,
            size: Float,
            color: Int = Color.WHITE
        ): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 8, 0, 8)
            }
        }

        root.addView(makeText("SMC ICT SIGNAL PRO", 25f))
        root.addView(
            makeText(
                "STRICT SMC / ICT SCANNER",
                14f,
                Color.rgb(80, 210, 160)
            )
        )

        root.addView(makeText("Select Market", 15f))

        market = Spinner(this)
        market.adapter = whiteAdapter(instruments)
        root.addView(
            market,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                55
            )
        )

        root.addView(makeText("Entry Timeframe", 15f))

        timeframe = Spinner(this)
        timeframe.adapter = whiteAdapter(
            listOf("5m", "15m", "30m")
        )
        timeframe.setSelection(1)

        root.addView(
            timeframe,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                55
            )
        )

        scanButton = Button(this).apply {
            text = "SCAN SMC / ICT SETUP"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(30, 130, 105))
            setOnClickListener {
                loadSignal()
            }
        }

        root.addView(
            scanButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                58
            )
        )

        status = makeText(
            "Ready. Internet connection required.",
            13f,
            Color.LTGRAY
        )
        root.addView(status)

        val scroll = ScrollView(this)

        resultBox = makeText(
            "Select a crypto market and tap SCAN.",
            16f
        )

        resultBox.setPadding(16, 18, 16, 18)
        resultBox.setBackgroundColor(
            Color.rgb(24, 37, 56)
        )

        scroll.addView(resultBox)

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1f
        )
        params.topMargin = 10

        root.addView(scroll, params)

        root.addView(
            makeText(
                "Data: Binance. Strict rule-based SMC/ICT prototype. " +
                "No guaranteed signals or profits.",
                11f,
                Color.LTGRAY
            )
        )

        setContentView(root)
    }

    private fun whiteAdapter(items: List<String>): ArrayAdapter<String> {

        return object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_spinner_item,
            items
        ) {

            override fun getView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return super.getView(
                    position,
                    convertView,
                    parent
                ).apply {
                    (this as TextView).setTextColor(Color.WHITE)
                    textSize = 16f
                }
            }

            override fun getDropDownView(
                position: Int,
                convertView: View?,
                parent: ViewGroup
            ): View {
                return super.getDropDownView(
                    position,
                    convertView,
                    parent
                ).apply {
                    (this as TextView).apply {
                        setTextColor(Color.WHITE)
                        setBackgroundColor(
                            Color.rgb(24, 37, 56)
                        )
                        textSize = 16f
                        setPadding(18, 18, 18, 18)
                    }
                }
            }
        }.also {
            it.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
            )
        }
    }

    private fun loadSignal() {

        val symbol = instruments[market.selectedItemPosition]
            .replace("/", "")

        val entryInterval = timeframe.selectedItem.toString()

        scanButton.isEnabled = false
        status.text = "Fetching 4H, 1H and $entryInterval candles..."
        resultBox.text = "Analyzing market structure..."

        thread {

            try {

                val fourHour = fetchCandles(symbol, "4h")
                val oneHour = fetchCandles(symbol, "1h")
                val entryCandles = fetchCandles(symbol, entryInterval)

                val htf = analyzeStructure(fourHour)
                val hourly = analyzeLiquidity(oneHour)
                val entryAnalysis = analyzeEntry(entryCandles)

                val signal = buildSignal(
                    htf,
                    hourly,
                    entryAnalysis,
                    entryCandles
                )

                runOnUiThread {

                    status.text =
                        "Analysis updated from Binance live candles."

                    showSignal(
                        symbol,
                        entryInterval,
                        htf,
                        hourly,
                        entryAnalysis,
                        signal
                    )

                    scanButton.isEnabled = true
                }

            } catch (e: Exception) {

                runOnUiThread {

                    status.text = "Market data error."

                    resultBox.text =
                        "Unable to analyze market.\n\n" +
                        "${e.message}\n\n" +
                        "Check internet connection and try again."

                    resultBox.setTextColor(Color.WHITE)
                    scanButton.isEnabled = true
                }
            }
        }
    }

    private fun fetchCandles(
        symbol: String,
        interval: String
    ): List<Candle> {

        val endpoint =
            "https://api.binance.com/api/v3/klines" +
            "?symbol=$symbol&interval=$interval&limit=150"

        val connection =
            URL(endpoint).openConnection() as HttpURLConnection

        connection.requestMethod = "GET"
        connection.connectTimeout = 15000
        connection.readTimeout = 15000

        val code = connection.responseCode

        val stream =
            if (code in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

        val body = stream.bufferedReader().use {
            it.readText()
        }

        connection.disconnect()

        if (code !in 200..299) {
            throw Exception("Binance API: $body")
        }

        val json = JSONArray(body)
        val candles = mutableListOf<Candle>()

        // Exclude the last candle because it may still be forming.
        for (i in 0 until json.length() - 1) {

            val row = json.getJSONArray(i)

            candles.add(
                Candle(
                    row.getString(1).toDouble(),
                    row.getString(2).toDouble(),
                    row.getString(3).toDouble(),
                    row.getString(4).toDouble()
                )
            )
        }

        if (candles.size < 40) {
            throw Exception("Not enough closed candles.")
        }

        return candles
    }

    private fun analyzeStructure(
        candles: List<Candle>
    ): Analysis {

        val recent = candles.takeLast(30)

        val oldHigh = recent.dropLast(10).maxOf {
            it.high
        }

        val oldLow = recent.dropLast(10).minOf {
            it.low
        }

        val current = recent.takeLast(10)

        val newHigh = current.maxOf { it.high }
        val newLow = current.minOf { it.low }

        val bullish =
            newHigh > oldHigh && newLow > oldLow

        val bearish =
            newLow < oldLow && newHigh < oldHigh

        return Analysis(
            bullish,
            bearish,
            when {
                bullish -> "4H Bullish Structure"
                bearish -> "4H Bearish Structure"
                else -> "4H Structure Unclear"
            }
        )
    }

    private fun analyzeLiquidity(
        candles: List<Candle>
    ): Analysis {

        val recent = candles.takeLast(25)

        val reference = recent.dropLast(3)

        val previousLow = reference.minOf {
            it.low
        }

        val previousHigh = reference.maxOf {
            it.high
        }

        val last = recent.last()

        val sellSideSweep =
            last.low < previousLow &&
            last.close > previousLow

        val buySideSweep =
            last.high > previousHigh &&
            last.close < previousHigh

        val bullishBreak =
            last.close > reference.takeLast(10).maxOf {
                it.high
            }

        val bearishBreak =
            last.close < reference.takeLast(10).minOf {
                it.low
            }

        val bullish =
            sellSideSweep && bullishBreak

        val bearish =
            buySideSweep && bearishBreak

        return Analysis(
            bullish,
            bearish,
            when {
                bullish -> "Sell-side sweep + Bullish structure break"
                bearish -> "Buy-side sweep + Bearish structure break"
                else -> "No confirmed 1H liquidity sweep + break"
            }
        )
    }

    private fun analyzeEntry(
        candles: List<Candle>
    ): Analysis {

        val recent = candles.takeLast(30)

        val bullishFvg = mutableListOf<Int>()
        val bearishFvg = mutableListOf<Int>()

        for (i in 2 until recent.size) {

            val first = recent[i - 2]
            val middle = recent[i - 1]
            val third = recent[i]

            val bullishGap =
                third.low > first.high

            val bearishGap =
                third.high < first.low

            val bullishDisplacement =
                middle.close > middle.open &&
                (middle.close - middle.open) >
                (middle.high - middle.low) * 0.60

            val bearishDisplacement =
                middle.close < middle.open &&
                (middle.open - middle.close) >
                (middle.high - middle.low) * 0.60

            if (bullishGap && bullishDisplacement) {
                bullishFvg.add(i)
            }

            if (bearishGap && bearishDisplacement) {
                bearishFvg.add(i)
            }
        }

        val lastPrice = recent.last().close

        val bullishRetest = bullishFvg.any { index ->

            val lower = recent[index - 2].high
            val upper = recent[index].low

            lastPrice in lower..upper
        }

        val bearishRetest = bearishFvg.any { index ->

            val lower = recent[index].high
            val upper = recent[index - 2].low

            lastPrice in lower..upper
        }

        return Analysis(
            bullishRetest,
            bearishRetest,
            when {
                bullishRetest -> "Bullish FVG Retest"
                bearishRetest -> "Bearish FVG Retest"
                else -> "No confirmed FVG retest"
            }
        )
    }

    private fun buildSignal(
        htf: Analysis,
        hourly: Analysis,
        entryAnalysis: Analysis,
        candles: List<Candle>
    ): Signal {

        val price = candles.last().close

        val recent = candles.takeLast(20)

        val rangeHigh = recent.maxOf { it.high }
        val rangeLow = recent.minOf { it.low }

        val midpoint = (rangeHigh + rangeLow) / 2.0

        val bullishDiscount = price < midpoint
        val bearishPremium = price > midpoint

        val bullish =
            htf.bullish &&
            hourly.bullish &&
            entryAnalysis.bullish &&
            bullishDiscount

        val bearish =
            htf.bearish &&
            hourly.bearish &&
            entryAnalysis.bearish &&
            bearishPremium

        if (!bullish && !bearish) {

            return Signal(
                "WAIT",
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                "All required confirmations are not present.\n" +
                "No trade should be taken."
            )
        }

        val isBuy = bullish

        val entry = price

        val stop = if (isBuy) {
            rangeLow
        } else {
            rangeHigh
        }

        val risk = abs(entry - stop)

        if (risk <= 0.0) {
            return Signal(
                "WAIT", 0.0, 0.0, 0.0, 0.0, 0.0,
                "Invalid risk calculation."
            )
        }

        val direction = if (isBuy) 1.0 else -1.0

        return Signal(
            if (isBuy) "BUY" else "SELL",
            entry,
            stop,
            entry + direction * risk,
            entry + direction * risk * 2.0,
            entry + direction * risk * 3.0,
            "4H Structure confirmed\n" +
            "1H Liquidity sweep and break confirmed\n" +
            "15m FVG retest confirmed\n" +
            if (isBuy) {
                "Price in Discount zone"
            } else {
                "Price in Premium zone"
            }
        )
    }

    private fun showSignal(
        symbol: String,
        interval: String,
        htf: Analysis,
        hourly: Analysis,
        entryAnalysis: Analysis,
        signal: Signal
    ) {

        val output = StringBuilder()

        output.append("SYMBOL: $symbol\n")
        output.append("ENTRY TIMEFRAME: $interval\n\n")

        output.append("4H: ${htf.description}\n")
        output.append("1H: ${hourly.description}\n")
        output.append("ENTRY: ${entryAnalysis.description}\n\n")

        output.append("SIGNAL: ${signal.direction}\n\n")

        if (signal.direction != "WAIT") {

            val risk = abs(signal.entry - signal.stop)

            val reward = abs(signal.target1 - signal.entry)

            val rr = if (risk > 0) reward / risk else 0.0

            output.append("ENTRY: ${df.format(signal.entry)}\n")
            output.append("STOP LOSS: ${df.format(signal.stop)}\n")
            output.append("TARGET 1: ${df.format(signal.target1)}\n")
            output.append("TARGET 2: ${df.format(signal.target2)}\n")
            output.append("TARGET 3: ${df.format(signal.target3)}\n")
            output.append("RISK / REWARD: 1:${df.format(rr)}\n\n")
        }

        output.append(signal.details)

        output.append(
            "\n\nStrict rule-based prototype. " +
            "Backtest and paper-trade before using real money."
        )

        resultBox.text = output.toString()

        resultBox.setTextColor(
            when (signal.direction) {
                "BUY" -> Color.rgb(80, 230, 150)
                "SELL" -> Color.rgb(255, 100, 110)
                else -> Color.WHITE
            }
        )
    }
}